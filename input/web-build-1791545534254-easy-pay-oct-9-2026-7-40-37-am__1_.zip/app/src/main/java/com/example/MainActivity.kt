package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.data.EasyPayDatabase
import com.example.data.repository.EasyPayRepository
import com.example.ui.components.EasyPayTopBar
import com.example.ui.components.ReceiptDialog
import com.example.ui.screens.*
import com.example.ui.theme.EasyPayTheme
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateBackground
import com.example.ui.util.LocalizedStrings
import com.example.viewmodel.EasyPayViewModel
import com.example.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private lateinit var database: EasyPayDatabase
    private lateinit var repository: EasyPayRepository
    private lateinit var viewModel: EasyPayViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        database = EasyPayDatabase.getDatabase(applicationContext, lifecycleScope)
        repository = EasyPayRepository(database.easyPayDao())
        viewModel = EasyPayViewModel(repository)

        setContent {
            EasyPayTheme {
                MainContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainContent(viewModel: EasyPayViewModel) {
    val user by viewModel.userAccount.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val beneficiaries by viewModel.beneficiaries.collectAsStateWithLifecycle()
    val moneyRequests by viewModel.moneyRequests.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val supportTickets by viewModel.supportTickets.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val isBalanceVisible by viewModel.isBalanceVisible.collectAsStateWithLifecycle()
    val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()
    val selectedTransaction by viewModel.selectedTransaction.collectAsStateWithLifecycle()
    val operationStatus by viewModel.operationStatus.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(operationStatus) {
        operationStatus?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatus()
        }
    }

    val unreadNotifications = notifications.count { !it.isRead }

    // Bottom Navigation Bar visible on top-level screens
    val isTopLevelScreen = activeScreen in listOf(
        Screen.Home,
        Screen.Transactions,
        Screen.PayAndBills,
        Screen.AdminConsole,
        Screen.Profile
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (activeScreen == Screen.Home) {
                EasyPayTopBar(
                    language = currentLanguage,
                    unreadNotificationCount = unreadNotifications,
                    onLanguageToggle = { viewModel.toggleLanguage() },
                    onNotificationsClick = { viewModel.navigateTo(Screen.Notifications) },
                    onAdminClick = { viewModel.navigateTo(Screen.AdminConsole) }
                )
            }
        },
        bottomBar = {
            if (isTopLevelScreen) {
                NavigationBar(
                    containerColor = PureWhite,
                    tonalElevation = 8.dp,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("bottom_nav_bar")
                ) {
                    NavigationBarItem(
                        selected = activeScreen == Screen.Home,
                        onClick = { viewModel.navigateTo(Screen.Home) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text(LocalizedStrings.get("home", currentLanguage)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            indicatorColor = EmeraldPrimary
                        ),
                        modifier = Modifier.testTag("nav_item_home")
                    )
                    NavigationBarItem(
                        selected = activeScreen == Screen.Transactions,
                        onClick = { viewModel.navigateTo(Screen.Transactions) },
                        icon = { Icon(Icons.Default.History, contentDescription = "History") },
                        label = { Text(LocalizedStrings.get("transactions", currentLanguage)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            indicatorColor = EmeraldPrimary
                        ),
                        modifier = Modifier.testTag("nav_item_history")
                    )
                    NavigationBarItem(
                        selected = activeScreen == Screen.PayAndBills,
                        onClick = { viewModel.navigateTo(Screen.PayAndBills) },
                        icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Pay & Bills") },
                        label = { Text(LocalizedStrings.get("pay_bills", currentLanguage)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            indicatorColor = EmeraldPrimary
                        ),
                        modifier = Modifier.testTag("nav_item_pay")
                    )
                    NavigationBarItem(
                        selected = activeScreen == Screen.AdminConsole,
                        onClick = { viewModel.navigateTo(Screen.AdminConsole) },
                        icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin") },
                        label = { Text(LocalizedStrings.get("admin", currentLanguage)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            indicatorColor = EmeraldPrimary
                        ),
                        modifier = Modifier.testTag("nav_item_admin")
                    )
                    NavigationBarItem(
                        selected = activeScreen == Screen.Profile,
                        onClick = { viewModel.navigateTo(Screen.Profile) },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text(LocalizedStrings.get("profile", currentLanguage)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            indicatorColor = EmeraldPrimary
                        ),
                        modifier = Modifier.testTag("nav_item_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(SlateBackground)
        ) {
            when (activeScreen) {
                Screen.Home -> {
                    HomeScreen(
                        user = user,
                        transactions = transactions,
                        moneyRequests = moneyRequests,
                        isBalanceVisible = isBalanceVisible,
                        language = currentLanguage,
                        onToggleBalanceVisibility = { viewModel.toggleBalanceVisibility() },
                        onNavigate = { screen -> viewModel.navigateTo(screen) },
                        onTransactionClick = { txn -> viewModel.showReceipt(txn) }
                    )
                }

                Screen.Transactions -> {
                    TransactionHistoryScreen(
                        transactions = transactions,
                        language = currentLanguage,
                        onBack = { viewModel.navigateBack() },
                        onTransactionClick = { txn -> viewModel.showReceipt(txn) }
                    )
                }

                Screen.PayAndBills -> {
                    PayAndBillsScreen(
                        user = user,
                        onBack = { viewModel.navigateBack() },
                        onInquireTitle = { rail, inst, id -> viewModel.inquireTitle(rail, inst, id) },
                        onExecuteTransfer = { req, pin, onDone -> viewModel.executeTransfer(req, pin, onDone) }
                    )
                }

                Screen.AdminConsole -> {
                    AdminConsoleScreen(
                        user = user,
                        transactions = transactions,
                        supportTickets = supportTickets,
                        auditLogs = auditLogs,
                        onBack = { viewModel.navigateBack() },
                        onDepositSandbox = { amt -> viewModel.adminDepositSandboxFunds(amt) },
                        onUpgradeKyc = { tier, status -> viewModel.adminUpgradeKyc(tier, status) },
                        onToggleLock = { lock -> viewModel.adminToggleLock(lock) },
                        onResolveTicket = { id, resp -> viewModel.adminResolveTicket(id, resp) }
                    )
                }

                Screen.Profile -> {
                    ProfileScreen(
                        user = user,
                        language = currentLanguage,
                        onBack = { viewModel.navigateBack() },
                        onLanguageToggle = { viewModel.toggleLanguage() },
                        onNavigate = { screen -> viewModel.navigateTo(screen) }
                    )
                }

                Screen.BankTransfer -> {
                    BankTransferScreen(
                        user = user,
                        onBack = { viewModel.navigateBack() },
                        onInquireTitle = { rail, inst, id -> viewModel.inquireTitle(rail, inst, id) },
                        onExecuteTransfer = { req, pin, onDone -> viewModel.executeTransfer(req, pin, onDone) },
                        onSaveBeneficiary = { name, nick, acc, inst, type ->
                            viewModel.addBeneficiary(name, nick, acc, inst, type)
                        }
                    )
                }

                Screen.WalletTransfer -> {
                    WalletTransferScreen(
                        user = user,
                        onBack = { viewModel.navigateBack() },
                        onInquireTitle = { rail, inst, id -> viewModel.inquireTitle(rail, inst, id) },
                        onExecuteTransfer = { req, pin, onDone -> viewModel.executeTransfer(req, pin, onDone) },
                        onSaveBeneficiary = { name, nick, acc, inst, type ->
                            viewModel.addBeneficiary(name, nick, acc, inst, type)
                        }
                    )
                }

                Screen.RequestMoney -> {
                    RequestMoneyScreen(
                        moneyRequests = moneyRequests,
                        onBack = { viewModel.navigateBack() },
                        onCreateRequest = { phone, amt, note, onDone ->
                            viewModel.sendMoneyRequest(phone, amt, note, onDone)
                        },
                        onFulfillRequest = { req, pin, onDone ->
                            viewModel.fulfillRequest(req, pin, onDone)
                        },
                        onDeclineRequest = { id -> viewModel.declineRequest(id) }
                    )
                }

                Screen.ReceiveMoney -> {
                    ReceiveMoneyScreen(
                        user = user,
                        onBack = { viewModel.navigateBack() }
                    )
                }

                Screen.QrScanner -> {
                    QrPayScreen(
                        user = user,
                        onBack = { viewModel.navigateBack() },
                        onExecuteTransfer = { req, pin, onDone -> viewModel.executeTransfer(req, pin, onDone) }
                    )
                }

                Screen.Beneficiaries -> {
                    BeneficiaryScreen(
                        beneficiaries = beneficiaries,
                        onBack = { viewModel.navigateBack() },
                        onAddBeneficiary = { name, nick, acc, inst, type ->
                            viewModel.addBeneficiary(name, nick, acc, inst, type)
                        },
                        onDeleteBeneficiary = { item -> viewModel.deleteBeneficiary(item) },
                        onSelectForTransfer = { item ->
                            if (item.type == "BANK") {
                                viewModel.navigateTo(Screen.BankTransfer)
                            } else {
                                viewModel.navigateTo(Screen.WalletTransfer)
                            }
                        }
                    )
                }

                Screen.Notifications -> {
                    NotificationsScreen(
                        notifications = notifications,
                        onBack = { viewModel.navigateBack() },
                        onMarkAllRead = { viewModel.markAllNotificationsRead() }
                    )
                }

                Screen.SupportCenter -> {
                    SupportCenterScreen(
                        tickets = supportTickets,
                        onBack = { viewModel.navigateBack() },
                        onSubmitTicket = { sub, ref, prio, msg, onDone ->
                            viewModel.fileSupportTicket(sub, ref, prio, msg, onDone)
                        }
                    )
                }

                Screen.KycUpgrade -> {
                    AdminConsoleScreen(
                        user = user,
                        transactions = transactions,
                        supportTickets = supportTickets,
                        auditLogs = auditLogs,
                        onBack = { viewModel.navigateBack() },
                        onDepositSandbox = { amt -> viewModel.adminDepositSandboxFunds(amt) },
                        onUpgradeKyc = { tier, status -> viewModel.adminUpgradeKyc(tier, status) },
                        onToggleLock = { lock -> viewModel.adminToggleLock(lock) },
                        onResolveTicket = { id, resp -> viewModel.adminResolveTicket(id, resp) }
                    )
                }
            }
        }
    }

    // Modal e-Receipt Dialog
    selectedTransaction?.let { txn ->
        ReceiptDialog(
            transaction = txn,
            onDismiss = { viewModel.dismissReceipt() },
            onDispute = { disputedTxn ->
                viewModel.dismissReceipt()
                viewModel.navigateTo(Screen.SupportCenter)
            }
        )
    }
}
