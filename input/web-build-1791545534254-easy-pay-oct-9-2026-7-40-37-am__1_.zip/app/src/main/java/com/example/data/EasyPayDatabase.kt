package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.EasyPayDao
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserAccount::class,
        TransactionItem::class,
        BeneficiaryItem::class,
        MoneyRequestItem::class,
        NotificationItem::class,
        SupportTicketItem::class,
        AuditLogItem::class
    ],
    version = 1,
    exportSchema = false
)
abstract class EasyPayDatabase : RoomDatabase() {

    abstract fun easyPayDao(): EasyPayDao

    companion object {
        @Volatile
        private var INSTANCE: EasyPayDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): EasyPayDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EasyPayDatabase::class.java,
                    "easypay_fintech.db"
                )
                    .addCallback(EasyPayDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class EasyPayDatabaseCallback(
        private val scope: CoroutineScope
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.easyPayDao())
                }
            }
        }

        private suspend fun populateInitialData(dao: EasyPayDao) {
            // Seed default primary user
            val primaryUser = UserAccount(
                id = 1L,
                fullName = "Muhammad Hamza",
                mobileNumber = "0301-8472910",
                cnic = "42101-9482716-3",
                email = "hamza.finance@easypay.pk",
                balance = 74500.0,
                dailyLimit = 50000.0,
                dailySpent = 12500.0,
                monthlyLimit = 200000.0,
                monthlySpent = 35000.0,
                kycTier = "TIER_1_VERIFIED",
                kycStatus = "Verification Approved",
                raastId = "03018472910@raast",
                iban = "PK72EPAY0000103018472910",
                pin = "1234",
                biometricsEnabled = true,
                isRestricted = false
            )
            dao.insertUserAccount(primaryUser)

            val now = System.currentTimeMillis()
            val oneDay = 86400000L

            // Seed sample Pakistani transactions
            dao.insertTransaction(
                TransactionItem(
                    referenceNumber = "EP-20261008-842109",
                    stan = "842109",
                    rrn = "261008842109",
                    title = "IBFT to Meezan Bank",
                    type = "BANK_TRANSFER",
                    amount = 8500.0,
                    fee = 0.0,
                    recipientName = "Tariq Mahmood",
                    recipientAccount = "02010103829102",
                    destinationInstitution = "Meezan Bank",
                    status = "SUCCESSFUL",
                    timestamp = now - (3600000L * 3),
                    note = "Family expense transfer",
                    purposeOfPayment = "Family Support"
                )
            )

            dao.insertTransaction(
                TransactionItem(
                    referenceNumber = "EP-20261007-391820",
                    stan = "391820",
                    rrn = "261007391820",
                    title = "Electricity Bill Payment",
                    type = "BILL_PAYMENT",
                    amount = 4000.0,
                    fee = 0.0,
                    recipientName = "Lahore Electric Supply Co",
                    recipientAccount = "08112739102837",
                    destinationInstitution = "LESCO",
                    status = "SUCCESSFUL",
                    timestamp = now - oneDay,
                    note = "September Electricity Bill",
                    purposeOfPayment = "Utility Bill"
                )
            )

            dao.insertTransaction(
                TransactionItem(
                    referenceNumber = "EP-20261006-119283",
                    stan = "119283",
                    rrn = "261006119283",
                    title = "Received via Raast P2P",
                    type = "RECEIVED_PAYMENT",
                    amount = 15000.0,
                    fee = 0.0,
                    recipientName = "Muhammad Hamza",
                    recipientAccount = "03018472910@raast",
                    destinationInstitution = "JazzCash (Sender: Fatima Noor)",
                    status = "SUCCESSFUL",
                    timestamp = now - (oneDay * 2),
                    note = "Freelance UI work milestone",
                    purposeOfPayment = "Consulting Fee"
                )
            )

            dao.insertTransaction(
                TransactionItem(
                    referenceNumber = "EP-20261005-772810",
                    stan = "772810",
                    rrn = "261005772810",
                    title = "Mobile Bundle Super Max",
                    type = "MOBILE_TOPUP",
                    amount = 450.0,
                    fee = 0.0,
                    recipientName = "Muhammad Hamza",
                    recipientAccount = "0301-8472910",
                    destinationInstitution = "Jazz",
                    status = "SUCCESSFUL",
                    timestamp = now - (oneDay * 3),
                    note = "Weekly 30GB Data + 1000 Mins",
                    purposeOfPayment = "Mobile Prepaid"
                )
            )

            dao.insertTransaction(
                TransactionItem(
                    referenceNumber = "EP-20261004-992019",
                    stan = "992019",
                    rrn = "261004992019",
                    title = "SNGPL Gas Bill",
                    type = "BILL_PAYMENT",
                    amount = 1820.0,
                    fee = 0.0,
                    recipientName = "Sui Northern Gas Pipelines",
                    recipientAccount = "82910294819",
                    destinationInstitution = "SNGPL",
                    status = "SUCCESSFUL",
                    timestamp = now - (oneDay * 4),
                    note = "Residential Gas Bill",
                    purposeOfPayment = "Utility Bill"
                )
            )

            // Seed Beneficiaries
            dao.insertBeneficiary(
                BeneficiaryItem(
                    name = "Tariq Mahmood",
                    nickname = "Uncle Tariq",
                    accountOrPhone = "02010103829102",
                    institution = "Meezan Bank",
                    type = "BANK",
                    isFavorite = true
                )
            )
            dao.insertBeneficiary(
                BeneficiaryItem(
                    name = "Ayesha Khan",
                    nickname = "Ayesha (Sister)",
                    accountOrPhone = "PK89HABB0001928374615243",
                    institution = "Habib Bank Limited (HBL)",
                    type = "BANK",
                    isFavorite = true
                )
            )
            dao.insertBeneficiary(
                BeneficiaryItem(
                    name = "Bilal Ahmed",
                    nickname = "Bilal Roommate",
                    accountOrPhone = "0300-9876543",
                    institution = "JazzCash",
                    type = "WALLET",
                    isFavorite = false
                )
            )
            dao.insertBeneficiary(
                BeneficiaryItem(
                    name = "Zainab Bibi",
                    nickname = "Zainab Tailor",
                    accountOrPhone = "0345-1234567",
                    institution = "Easypaisa",
                    type = "WALLET",
                    isFavorite = false
                )
            )

            // Seed Money Request
            dao.insertMoneyRequest(
                MoneyRequestItem(
                    requesterName = "Usman Ghani",
                    requesterPhone = "0333-1122334",
                    payerPhone = "0301-8472910",
                    amount = 3500.0,
                    note = "Dinner split at Monal Islamabad",
                    status = "PENDING",
                    createdAt = now - (3600000L * 5)
                )
            )

            // Seed Notifications
            dao.insertNotification(
                NotificationItem(
                    title = "Raast Payment Received",
                    message = "Rs. 15,000 received from Fatima Noor via Raast Instant Transfer.",
                    type = "TRANSFER",
                    timestamp = now - (oneDay * 2),
                    isRead = false
                )
            )
            dao.insertNotification(
                NotificationItem(
                    title = "State Bank Regulatory Sandbox",
                    message = "EASY PAY is operating in compliance sandbox mode. Financial transfers simulate actual clearing rails.",
                    type = "COMPLIANCE",
                    timestamp = now - (oneDay * 3),
                    isRead = true
                )
            )
            dao.insertNotification(
                NotificationItem(
                    title = "Biometric Login Configured",
                    message = "Your fingerprint/Face ID authorization was successfully registered.",
                    type = "SECURITY",
                    timestamp = now - (oneDay * 5),
                    isRead = true
                )
            )

            // Seed Support Ticket
            dao.insertSupportTicket(
                SupportTicketItem(
                    ticketRef = "EP-TK-9021",
                    subject = "LESCO e-Receipt verification inquiry",
                    relatedTxnRef = "EP-20261007-391820",
                    status = "RESOLVED",
                    priority = "NORMAL",
                    message = "Paid bill on Oct 7. Needed biller consumer confirmation stamp.",
                    adminResponse = "LESCO switch confirmed settlement at 11:42 PM. Consumer bill marked PAID with 1Link reference.",
                    createdAt = now - (oneDay * 1)
                )
            )

            // Seed Audit Logs
            dao.insertAuditLog(
                AuditLogItem(
                    action = "ACCOUNT_INITIALIZED",
                    actor = "SYSTEM_SEEDED",
                    details = "Account initialized under SBP Electronic Money Institution (EMI) Tier 1 limits.",
                    timestamp = now - (oneDay * 7)
                )
            )
            dao.insertAuditLog(
                AuditLogItem(
                    action = "KYC_VERIFIED",
                    actor = "COMPLIANCE_AGENT_04",
                    details = "CNIC 42101-9482716-3 NADRA biometric verified successfully.",
                    timestamp = now - (oneDay * 6)
                )
            )
        }
    }
}
