package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EasyPayDao {

    @Query("SELECT * FROM user_account WHERE id = 1 LIMIT 1")
    fun getUserAccount(): Flow<UserAccount?>

    @Query("SELECT * FROM user_account WHERE id = 1 LIMIT 1")
    suspend fun getUserAccountSync(): UserAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserAccount(user: UserAccount)

    @Update
    suspend fun updateUserAccount(user: UserAccount)

    @Query("UPDATE user_account SET balance = :newBalance, dailySpent = :newDailySpent, monthlySpent = :newMonthlySpent WHERE id = 1")
    suspend fun updateBalanceAndSpend(newBalance: Double, newDailySpent: Double, newMonthlySpent: Double)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionItem>>

    @Query("SELECT * FROM transactions WHERE referenceNumber = :ref LIMIT 1")
    suspend fun getTransactionByRef(ref: String): TransactionItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(item: TransactionItem): Long

    @Query("UPDATE transactions SET status = :status WHERE id = :id")
    suspend fun updateTransactionStatus(id: Long, status: String)

    @Query("SELECT * FROM beneficiaries ORDER BY isFavorite DESC, name ASC")
    fun getAllBeneficiaries(): Flow<List<BeneficiaryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBeneficiary(item: BeneficiaryItem): Long

    @Delete
    suspend fun deleteBeneficiary(item: BeneficiaryItem)

    @Query("SELECT * FROM money_requests ORDER BY createdAt DESC")
    fun getAllMoneyRequests(): Flow<List<MoneyRequestItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMoneyRequest(item: MoneyRequestItem): Long

    @Query("UPDATE money_requests SET status = :status WHERE id = :id")
    suspend fun updateMoneyRequestStatus(id: Long, status: String)

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(item: NotificationItem): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: Long)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllNotificationsAsRead()

    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun getAllSupportTickets(): Flow<List<SupportTicketItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupportTicket(item: SupportTicketItem): Long

    @Query("UPDATE support_tickets SET status = :status, adminResponse = :response WHERE id = :id")
    suspend fun updateTicketStatusAndResponse(id: Long, status: String, response: String)

    @Update
    suspend fun updateSupportTicket(ticket: SupportTicketItem)

    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogs(): Flow<List<AuditLogItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(item: AuditLogItem): Long
}
