package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_account")
data class UserAccount(
    @PrimaryKey
    val id: Long = 1L,
    val fullName: String,
    val mobileNumber: String,
    val cnic: String,
    val email: String,
    val balance: Double,
    val dailyLimit: Double,
    val dailySpent: Double,
    val monthlyLimit: Double,
    val monthlySpent: Double,
    val kycTier: String, // TIER_0_BASIC, TIER_1_VERIFIED, TIER_2_ENHANCED, TIER_3_MERCHANT
    val kycStatus: String, // Verification Approved, Pending, Under Review
    val raastId: String,
    val iban: String,
    val pin: String,
    val biometricsEnabled: Boolean = true,
    val isRestricted: Boolean = false
)

@Entity(tableName = "transactions")
data class TransactionItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val referenceNumber: String,
    val stan: String,
    val rrn: String,
    val title: String,
    val type: String, // BANK_TRANSFER, WALLET_TRANSFER, BILL_PAYMENT, MOBILE_TOPUP, REQUEST_PAID, RECEIVED_PAYMENT, CASH_IN
    val amount: Double,
    val fee: Double,
    val recipientName: String,
    val recipientAccount: String,
    val destinationInstitution: String,
    val status: String, // SUCCESSFUL, PENDING, FAILED, REVERSED
    val timestamp: Long,
    val note: String,
    val purposeOfPayment: String
)

@Entity(tableName = "beneficiaries")
data class BeneficiaryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val nickname: String,
    val accountOrPhone: String,
    val institution: String,
    val type: String, // BANK, WALLET, RAAST
    val isFavorite: Boolean = false
)

@Entity(tableName = "money_requests")
data class MoneyRequestItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val requesterName: String,
    val requesterPhone: String,
    val payerPhone: String,
    val amount: Double,
    val note: String,
    val status: String, // PENDING, ACCEPTED, DECLINED, PAID
    val createdAt: Long
)

@Entity(tableName = "notifications")
data class NotificationItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val message: String,
    val type: String, // TRANSFER, SECURITY, BILL, COMPLIANCE
    val timestamp: Long,
    val isRead: Boolean = false
)

@Entity(tableName = "support_tickets")
data class SupportTicketItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val ticketRef: String,
    val subject: String,
    val relatedTxnRef: String,
    val status: String, // OPEN, IN_REVIEW, RESOLVED
    val priority: String, // NORMAL, HIGH, URGENT
    val message: String,
    val adminResponse: String,
    val createdAt: Long
)

@Entity(tableName = "audit_logs")
data class AuditLogItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val action: String,
    val actor: String,
    val details: String,
    val timestamp: Long
)
