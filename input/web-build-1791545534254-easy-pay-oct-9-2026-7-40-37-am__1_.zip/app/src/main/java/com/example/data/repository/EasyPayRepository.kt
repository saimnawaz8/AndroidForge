package com.example.data.repository

import com.example.data.dao.EasyPayDao
import com.example.data.model.*
import com.example.service.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

sealed class TransactionResult {
    data class Success(val transaction: TransactionItem, val message: String) : TransactionResult()
    data class Error(val reason: String) : TransactionResult()
}

class EasyPayRepository(private val dao: EasyPayDao) {

    val userAccount: Flow<UserAccount?> = dao.getUserAccount()
    val transactions: Flow<List<TransactionItem>> = dao.getAllTransactions()
    val beneficiaries: Flow<List<BeneficiaryItem>> = dao.getAllBeneficiaries()
    val moneyRequests: Flow<List<MoneyRequestItem>> = dao.getAllMoneyRequests()
    val notifications: Flow<List<NotificationItem>> = dao.getAllNotifications()
    val supportTickets: Flow<List<SupportTicketItem>> = dao.getAllSupportTickets()
    val auditLogs: Flow<List<AuditLogItem>> = dao.getAllAuditLogs()

    suspend fun getUserSync(): UserAccount? = withContext(Dispatchers.IO) {
        dao.getUserAccountSync()
    }

    suspend fun verifyPin(enteredPin: String): Boolean = withContext(Dispatchers.IO) {
        val user = dao.getUserAccountSync() ?: return@withContext false
        user.pin == enteredPin
    }

    suspend fun executePayment(
        request: TransferRequest,
        enteredPin: String
    ): TransactionResult = withContext(Dispatchers.IO) {
        val user = dao.getUserAccountSync()
            ?: return@withContext TransactionResult.Error("User account not found")

        if (user.isRestricted) {
            return@withContext TransactionResult.Error("Account is restricted by compliance officer. Please contact customer support.")
        }

        if (user.pin != enteredPin) {
            return@withContext TransactionResult.Error("Incorrect 4-digit Transaction PIN entered.")
        }

        val totalDeduction = request.amount
        if (user.balance < totalDeduction) {
            return@withContext TransactionResult.Error("Insufficient balance in EASY PAY wallet. Available: PKR ${"%,.2f".format(user.balance)}")
        }

        if (user.dailySpent + request.amount > user.dailyLimit) {
            return@withContext TransactionResult.Error("Daily transaction limit exceeded (Max: PKR ${"%,.2f".format(user.dailyLimit)}).")
        }

        if (user.monthlySpent + request.amount > user.monthlyLimit) {
            return@withContext TransactionResult.Error("Monthly transaction limit exceeded for Tier ${user.kycTier}.")
        }

        // Route to payment rail
        val adapter = PaymentRouter.getAdapterFor(request.railType)
        val execResult = adapter.executeTransfer(request)

        if (!execResult.isSuccessful) {
            return@withContext TransactionResult.Error("Transfer rejected by ${adapter.railName}: ${execResult.message}")
        }

        // Atomically debit account
        val updatedBalance = user.balance - totalDeduction
        val updatedDailySpent = user.dailySpent + request.amount
        val updatedMonthlySpent = user.monthlySpent + request.amount
        dao.updateBalanceAndSpend(updatedBalance, updatedDailySpent, updatedMonthlySpent)

        // Save transaction
        val txnType = when (request.railType) {
            RailType.RAAST_P2P -> "BANK_TRANSFER"
            RailType.ONE_LINK_IBFT -> "BANK_TRANSFER"
            RailType.WALLET_DIRECT -> "WALLET_TRANSFER"
            RailType.ONE_BILL_UTILITY -> "BILL_PAYMENT"
            RailType.TELCO_PREPAID -> "MOBILE_TOPUP"
            RailType.QR_MERCHANT -> "QR_PAYMENT"
        }

        val txn = TransactionItem(
            referenceNumber = execResult.referenceNumber,
            stan = execResult.stan,
            rrn = execResult.rrn,
            title = when (request.railType) {
                RailType.RAAST_P2P -> "Raast Transfer to ${request.recipientTitle}"
                RailType.ONE_LINK_IBFT -> "IBFT to ${request.institution}"
                RailType.WALLET_DIRECT -> "Transfer to ${request.institution}"
                RailType.ONE_BILL_UTILITY -> "Bill Paid: ${request.institution}"
                RailType.TELCO_PREPAID -> "Recharge: ${request.institution}"
                RailType.QR_MERCHANT -> "QR Merchant: ${request.recipientTitle}"
            },
            type = txnType,
            amount = request.amount,
            fee = execResult.fee,
            recipientName = request.recipientTitle,
            recipientAccount = request.recipientIdentifier,
            destinationInstitution = request.institution,
            status = "SUCCESSFUL",
            timestamp = execResult.timestamp,
            note = request.note.ifBlank { request.purpose },
            purposeOfPayment = request.purpose
        )

        val id = dao.insertTransaction(txn)
        val savedTxn = txn.copy(id = id)

        // Notify user
        dao.insertNotification(
            NotificationItem(
                title = "Payment Successful: PKR ${"%,.2f".format(request.amount)}",
                message = "Sent to ${request.recipientTitle} (${request.institution}). Ref: ${execResult.referenceNumber}",
                type = "TRANSFER",
                timestamp = execResult.timestamp
            )
        )

        // Audit Log
        dao.insertAuditLog(
            AuditLogItem(
                action = "TRANSACTION_COMPLETED",
                actor = user.mobileNumber,
                details = "Debited PKR ${request.amount} to ${request.recipientTitle} via ${adapter.railName}. Stan: ${execResult.stan}",
                timestamp = execResult.timestamp
            )
        )

        TransactionResult.Success(savedTxn, execResult.message)
    }

    suspend fun createMoneyRequest(
        targetPhone: String,
        amount: Double,
        note: String
    ): Long = withContext(Dispatchers.IO) {
        val user = dao.getUserAccountSync() ?: return@withContext 0L
        val req = MoneyRequestItem(
            requesterName = user.fullName,
            requesterPhone = user.mobileNumber,
            payerPhone = targetPhone,
            amount = amount,
            note = note,
            status = "PENDING",
            createdAt = System.currentTimeMillis()
        )
        val id = dao.insertMoneyRequest(req)
        dao.insertNotification(
            NotificationItem(
                title = "Money Request Created",
                message = "Requested PKR ${"%,.2f".format(amount)} from $targetPhone.",
                type = "TRANSFER",
                timestamp = System.currentTimeMillis()
            )
        )
        id
    }

    suspend fun fulfillMoneyRequest(
        requestId: Long,
        requestItem: MoneyRequestItem,
        enteredPin: String
    ): TransactionResult = withContext(Dispatchers.IO) {
        val req = TransferRequest(
            amount = requestItem.amount,
            recipientIdentifier = requestItem.requesterPhone,
            recipientTitle = requestItem.requesterName,
            institution = "EASY PAY Wallet",
            purpose = "Request Fulfillment",
            note = requestItem.note,
            railType = RailType.WALLET_DIRECT
        )
        val result = executePayment(req, enteredPin)
        if (result is TransactionResult.Success) {
            dao.updateMoneyRequestStatus(requestId, "PAID")
        }
        result
    }

    suspend fun declineMoneyRequest(requestId: Long) = withContext(Dispatchers.IO) {
        dao.updateMoneyRequestStatus(requestId, "DECLINED")
    }

    suspend fun addBeneficiary(
        name: String,
        nickname: String,
        accountOrPhone: String,
        institution: String,
        type: String
    ): Long = withContext(Dispatchers.IO) {
        dao.insertBeneficiary(
            BeneficiaryItem(
                name = name,
                nickname = nickname.ifBlank { name },
                accountOrPhone = accountOrPhone,
                institution = institution,
                type = type,
                isFavorite = false
            )
        )
    }

    suspend fun deleteBeneficiary(item: BeneficiaryItem) = withContext(Dispatchers.IO) {
        dao.deleteBeneficiary(item)
    }

    suspend fun markNotificationRead(id: Long) = withContext(Dispatchers.IO) {
        dao.markNotificationAsRead(id)
    }

    suspend fun markAllNotificationsRead() = withContext(Dispatchers.IO) {
        dao.markAllNotificationsAsRead()
    }

    suspend fun fileSupportTicket(
        subject: String,
        relatedTxnRef: String,
        priority: String,
        message: String
    ): Long = withContext(Dispatchers.IO) {
        val ref = "EP-TK-" + (1000..9999).random()
        val item = SupportTicketItem(
            ticketRef = ref,
            subject = subject,
            relatedTxnRef = relatedTxnRef,
            status = "OPEN",
            priority = priority,
            message = message,
            adminResponse = "Ticket received. Our 24/7 compliance and customer disputes desk will review within 2 hours.",
            createdAt = System.currentTimeMillis()
        )
        val id = dao.insertSupportTicket(item)
        dao.insertNotification(
            NotificationItem(
                title = "Support Ticket Logged ($ref)",
                message = "Your inquiry regarding $relatedTxnRef has been registered with reference $ref.",
                type = "COMPLIANCE",
                timestamp = System.currentTimeMillis()
            )
        )
        id
    }

    // Admin & Sandbox Controls
    suspend fun updateKycTier(tier: String, status: String) = withContext(Dispatchers.IO) {
        val user = dao.getUserAccountSync() ?: return@withContext
        val (dailyLimit, monthlyLimit) = when (tier) {
            "TIER_1_VERIFIED" -> Pair(50000.0, 200000.0)
            "TIER_2_ENHANCED" -> Pair(200000.0, 1000000.0)
            "TIER_3_MERCHANT" -> Pair(1000000.0, 5000000.0)
            else -> Pair(25000.0, 100000.0)
        }
        val updated = user.copy(
            kycTier = tier,
            kycStatus = status,
            dailyLimit = dailyLimit,
            monthlyLimit = monthlyLimit
        )
        dao.updateUserAccount(updated)
        dao.insertAuditLog(
            AuditLogItem(
                action = "KYC_TIER_CHANGED",
                actor = "ADMIN_CONSOLE",
                details = "User KYC status changed to $tier ($status). Limits adjusted.",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun sandboxDeposit(amount: Double) = withContext(Dispatchers.IO) {
        val user = dao.getUserAccountSync() ?: return@withContext
        val newBalance = user.balance + amount
        dao.updateBalanceAndSpend(newBalance, user.dailySpent, user.monthlySpent)
        dao.insertTransaction(
            TransactionItem(
                referenceNumber = "EP-DEP-${System.currentTimeMillis() % 1000000}",
                stan = (100000..999999).random().toString(),
                rrn = "DEP" + System.currentTimeMillis().toString().takeLast(9),
                title = "Sandbox Top-Up Deposit",
                type = "CASH_IN",
                amount = amount,
                fee = 0.0,
                recipientName = user.fullName,
                recipientAccount = user.raastId,
                destinationInstitution = "EASY PAY Prototype Cash-In",
                status = "SUCCESSFUL",
                timestamp = System.currentTimeMillis(),
                note = "Simulated funds top-up for testing",
                purposeOfPayment = "Sandbox Topup"
            )
        )
        dao.insertNotification(
            NotificationItem(
                title = "Sandbox Funds Added",
                message = "Simulated deposit of PKR ${"%,.2f".format(amount)} added to testing balance.",
                type = "TRANSFER",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun toggleUserRestriction(restricted: Boolean) = withContext(Dispatchers.IO) {
        val user = dao.getUserAccountSync() ?: return@withContext
        dao.updateUserAccount(user.copy(isRestricted = restricted))
        dao.insertAuditLog(
            AuditLogItem(
                action = if (restricted) "ACCOUNT_RESTRICTED" else "ACCOUNT_UNRESTRICTED",
                actor = "COMPLIANCE_ADMIN",
                details = "Risk compliance officer modified account lock status to: $restricted",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun resolveSupportTicket(ticketId: Long, response: String) = withContext(Dispatchers.IO) {
        dao.updateTicketStatusAndResponse(ticketId, "RESOLVED", response)
        dao.insertAuditLog(
            AuditLogItem(
                action = "SUPPORT_TICKET_RESOLVED",
                actor = "ADMIN_CONSOLE",
                details = "Ticket #$ticketId marked resolved with response: $response",
                timestamp = System.currentTimeMillis()
            )
        )
    }
}
