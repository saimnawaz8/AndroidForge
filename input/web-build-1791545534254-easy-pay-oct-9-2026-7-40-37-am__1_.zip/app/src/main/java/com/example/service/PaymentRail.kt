package com.example.service

import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.random.Random

enum class RailType {
    RAAST_P2P,
    ONE_LINK_IBFT,
    WALLET_DIRECT,
    ONE_BILL_UTILITY,
    TELCO_PREPAID,
    QR_MERCHANT
}

data class RecipientInquiryResult(
    val isValid: Boolean,
    val recipientTitle: String,
    val institution: String,
    val identifier: String,
    val fee: Double,
    val railUsed: RailType,
    val message: String
)

data class TransferRequest(
    val amount: Double,
    val recipientIdentifier: String,
    val recipientTitle: String,
    val institution: String,
    val purpose: String,
    val note: String,
    val railType: RailType,
    val idempotencyKey: String = UUID.randomUUID().toString()
)

data class TransferExecutionResult(
    val isSuccessful: Boolean,
    val referenceNumber: String,
    val stan: String,
    val rrn: String,
    val fee: Double,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

interface PaymentRailAdapter {
    val railType: RailType
    val railName: String
    suspend fun inquireTitle(institution: String, identifier: String): RecipientInquiryResult
    suspend fun executeTransfer(request: TransferRequest): TransferExecutionResult
}

/**
 * State Bank of Pakistan (SBP) Raast Instant Payment Adapter
 * ISO 20022 compliant real-time payment rail with zero customer fee
 */
class RaastPaymentAdapter : PaymentRailAdapter {
    override val railType: RailType = RailType.RAAST_P2P
    override val railName: String = "Raast Instant (SBP)"

    override suspend fun inquireTitle(institution: String, identifier: String): RecipientInquiryResult {
        delay(400) // Realistic network round-trip simulation
        val cleanId = identifier.replace("-", "").trim()
        val title = when {
            cleanId.endsWith("10") -> "Muhammad Hamza"
            cleanId.endsWith("43") -> "Fatima Noor"
            cleanId.endsWith("67") -> "Kamran Tariq"
            cleanId.endsWith("02") -> "Tariq Mahmood"
            cleanId.endsWith("44") -> "Usman Ghani"
            else -> "Verified Raast Beneficiary (${cleanId.takeLast(4)})"
        }
        return RecipientInquiryResult(
            isValid = cleanId.length >= 10,
            recipientTitle = title,
            institution = "Raast P2P Switch",
            identifier = cleanId,
            fee = 0.0, // Raast SBP mandated 0 PKR fee
            railUsed = railType,
            message = "Raast Directory Service: Active Alias verified"
        )
    }

    override suspend fun executeTransfer(request: TransferRequest): TransferExecutionResult {
        delay(800)
        val rand = Random.nextInt(100000, 999999)
        val stan = rand.toString()
        val rrn = "26" + System.currentTimeMillis().toString().takeLast(10)
        val ref = "RST-${System.currentTimeMillis() % 10000000}-$stan"
        return TransferExecutionResult(
            isSuccessful = true,
            referenceNumber = ref,
            stan = stan,
            rrn = rrn,
            fee = 0.0,
            message = "Settled instantly via SBP Raast Clearing Engine"
        )
    }
}

/**
 * 1Link Inter-Bank Funds Transfer (1IBFT) Switch Adapter
 * Connects all commercial banks in Pakistan (HBL, Meezan, UBL, Alfalah, etc.)
 */
class OneLinkIBFTAdapter : PaymentRailAdapter {
    override val railType: RailType = RailType.ONE_LINK_IBFT
    override val railName: String = "1Link 1IBFT Switch"

    override suspend fun inquireTitle(institution: String, identifier: String): RecipientInquiryResult {
        delay(500)
        val cleanAcc = identifier.replace(" ", "").trim()
        val title = when {
            cleanAcc.contains("02010103829102") -> "Tariq Mahmood"
            cleanAcc.contains("HABB") -> "Ayesha Khan"
            cleanAcc.startsWith("PK") -> "Syed Ali Raza (Verified IBAN)"
            cleanAcc.length >= 8 -> "Account Holder: ${institution.take(6).trim()} Customer"
            else -> "Invalid Account Number"
        }
        val fee = if (cleanAcc.length >= 8) 0.0 else 0.0 // Promotion: 0 fee on mobile app
        return RecipientInquiryResult(
            isValid = cleanAcc.length >= 8,
            recipientTitle = title,
            institution = institution,
            identifier = cleanAcc,
            fee = fee,
            railUsed = railType,
            message = "1Link Title Fetch: Authorized"
        )
    }

    override suspend fun executeTransfer(request: TransferRequest): TransferExecutionResult {
        delay(900)
        val stan = Random.nextInt(100000, 999999).toString()
        val rrn = "1L" + System.currentTimeMillis().toString().takeLast(10)
        val ref = "EP-IBFT-${System.currentTimeMillis() % 10000000}"
        return TransferExecutionResult(
            isSuccessful = true,
            referenceNumber = ref,
            stan = stan,
            rrn = rrn,
            fee = 0.0,
            message = "Processed successfully by 1Link Switch to ${request.institution}"
        )
    }
}

/**
 * Digital Wallet Switch Adapter (Easypaisa, JazzCash, SadaPay, NayaPay)
 */
class DigitalWalletAdapter : PaymentRailAdapter {
    override val railType: RailType = RailType.WALLET_DIRECT
    override val railName: String = "Digital Wallet Switch"

    override suspend fun inquireTitle(institution: String, identifier: String): RecipientInquiryResult {
        delay(450)
        val cleanPhone = identifier.replace("-", "").replace(" ", "").trim()
        val title = when {
            cleanPhone.endsWith("43") -> "Bilal Ahmed"
            cleanPhone.endsWith("67") -> "Zainab Bibi"
            cleanPhone.endsWith("10") -> "Muhammad Hamza"
            else -> "$institution Verified User"
        }
        return RecipientInquiryResult(
            isValid = cleanPhone.length in 10..13,
            recipientTitle = title,
            institution = institution,
            identifier = cleanPhone,
            fee = 0.0,
            railUsed = railType,
            message = "Wallet API: Active wallet identified"
        )
    }

    override suspend fun executeTransfer(request: TransferRequest): TransferExecutionResult {
        delay(750)
        val stan = Random.nextInt(100000, 999999).toString()
        val rrn = "WAL" + System.currentTimeMillis().toString().takeLast(9)
        val ref = "EP-WLT-${System.currentTimeMillis() % 10000000}"
        return TransferExecutionResult(
            isSuccessful = true,
            referenceNumber = ref,
            stan = stan,
            rrn = rrn,
            fee = 0.0,
            message = "Credited directly to recipient's ${request.institution} wallet"
        )
    }
}

/**
 * 1Bill Utility & Government Bill Payment Aggregator
 */
class OneBillUtilityAdapter : PaymentRailAdapter {
    override val railType: RailType = RailType.ONE_BILL_UTILITY
    override val railName: String = "1Bill Aggregator"

    override suspend fun inquireTitle(institution: String, identifier: String): RecipientInquiryResult {
        delay(600)
        val cleanConsumer = identifier.replace(" ", "").trim()
        val title = "$institution Consumer #$cleanConsumer"
        return RecipientInquiryResult(
            isValid = cleanConsumer.length >= 6,
            recipientTitle = title,
            institution = institution,
            identifier = cleanConsumer,
            fee = 0.0,
            railUsed = railType,
            message = "1Bill Consumer verified. Bill Status: UNPAID"
        )
    }

    override suspend fun executeTransfer(request: TransferRequest): TransferExecutionResult {
        delay(950)
        val stan = Random.nextInt(100000, 999999).toString()
        val rrn = "BILL" + System.currentTimeMillis().toString().takeLast(8)
        val ref = "EP-BILL-${System.currentTimeMillis() % 10000000}"
        return TransferExecutionResult(
            isSuccessful = true,
            referenceNumber = ref,
            stan = stan,
            rrn = rrn,
            fee = 0.0,
            message = "Utility Bill Paid. 1Bill Aggregator Confirmation Generated."
        )
    }
}

/**
 * Telecom Top-Up and Bundle Adapter (Jazz, Zong, Ufone, Telenor)
 */
class TelecomTopupAdapter : PaymentRailAdapter {
    override val railType: RailType = RailType.TELCO_PREPAID
    override val railName: String = "Telco Direct Switch"

    override suspend fun inquireTitle(institution: String, identifier: String): RecipientInquiryResult {
        delay(300)
        val cleanPhone = identifier.replace("-", "").trim()
        return RecipientInquiryResult(
            isValid = cleanPhone.length in 10..13,
            recipientTitle = "$institution Prepaid Subscriber",
            institution = institution,
            identifier = cleanPhone,
            fee = 0.0,
            railUsed = railType,
            message = "Active Prepaid MSISDN confirmed"
        )
    }

    override suspend fun executeTransfer(request: TransferRequest): TransferExecutionResult {
        delay(700)
        val stan = Random.nextInt(100000, 999999).toString()
        val rrn = "TEL" + System.currentTimeMillis().toString().takeLast(9)
        val ref = "EP-TOP-${System.currentTimeMillis() % 10000000}"
        return TransferExecutionResult(
            isSuccessful = true,
            referenceNumber = ref,
            stan = stan,
            rrn = rrn,
            fee = 0.0,
            message = "Recharge successful. Package/Airtime active immediately."
        )
    }
}

/**
 * Intelligent Payment Router
 * Dynamically picks the optimal clearing rail (Raast first for zero fees and speed,
 * then 1Link IBFT, or direct wallet APIs).
 */
object PaymentRouter {
    val raastAdapter = RaastPaymentAdapter()
    val oneLinkAdapter = OneLinkIBFTAdapter()
    val walletAdapter = DigitalWalletAdapter()
    val utilityAdapter = OneBillUtilityAdapter()
    val telcoAdapter = TelecomTopupAdapter()

    fun getAdapterFor(railType: RailType): PaymentRailAdapter {
        return when (railType) {
            RailType.RAAST_P2P -> raastAdapter
            RailType.ONE_LINK_IBFT -> oneLinkAdapter
            RailType.WALLET_DIRECT -> walletAdapter
            RailType.ONE_BILL_UTILITY -> utilityAdapter
            RailType.TELCO_PREPAID -> telcoAdapter
            RailType.QR_MERCHANT -> raastAdapter
        }
    }
}
