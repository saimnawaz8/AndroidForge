package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionItem
import com.example.data.model.UserAccount
import com.example.ui.theme.*
import com.example.ui.util.AppLanguage
import com.example.ui.util.LocalizedStrings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EasyPayTopBar(
    language: AppLanguage,
    unreadNotificationCount: Int,
    onLanguageToggle: () -> Unit,
    onNotificationsClick: () -> Unit,
    onAdminClick: () -> Unit
) {
    Surface(
        color = EmeraldPrimary,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Logo & Brand Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.testTag("brand_header")
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PureWhite),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "EASY PAY",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "EASY PAY",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                ),
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(GoldAccent)
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "PK",
                                    color = NavyDark,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = LocalizedStrings.get("app_tagline", language),
                            style = MaterialTheme.typography.labelSmall,
                            color = MintLight
                        )
                    }
                }

                // Actions: Language Toggle & Notifications
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Language Switcher Pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = PureWhite.copy(alpha = 0.15f),
                        modifier = Modifier
                            .testTag("lang_toggle_btn")
                            .clickable { onLanguageToggle() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = PureWhite,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (language == AppLanguage.ENGLISH) "اردو" else "ENG",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = PureWhite
                            )
                        }
                    }

                    // Notification Bell with Badge
                    IconButton(
                        onClick = onNotificationsClick,
                        modifier = Modifier.testTag("notifications_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotificationCount > 0) {
                                    Badge(containerColor = GoldAccent, contentColor = NavyDark) {
                                        Text(text = unreadNotificationCount.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "Notifications",
                                tint = PureWhite
                            )
                        }
                    }
                }
            }

            // Prototype Notice Ribbon
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = NavyDark.copy(alpha = 0.5f),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sandbox_notice_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SBP Regulatory Sandbox • Functional Prototype",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = PureWhite.copy(alpha = 0.9f)
                        )
                    }
                    Text(
                        text = "Admin Portal >",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent,
                        modifier = Modifier
                            .clickable { onAdminClick() }
                            .padding(4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BalanceCard(
    user: UserAccount?,
    isBalanceVisible: Boolean,
    language: AppLanguage,
    onToggleVisibility: () -> Unit,
    onSendMoney: () -> Unit,
    onReceiveMoney: () -> Unit,
    onRequestMoney: () -> Unit,
    onScanQr: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("balance_card")
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(EmeraldPrimary, EmeraldMedium, EmeraldDark)
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                // Top row: Available Balance + Eye icon + Raast Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = LocalizedStrings.get("available_balance", language),
                                style = MaterialTheme.typography.bodyMedium,
                                color = PureWhite.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = onToggleVisibility,
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("toggle_balance_eye")
                            ) {
                                Icon(
                                    imageVector = if (isBalanceVisible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                                    contentDescription = "Toggle Balance",
                                    tint = PureWhite.copy(alpha = 0.85f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        // Amount Display
                        Text(
                            text = if (isBalanceVisible) "PKR ${"%,.2f".format(user?.balance ?: 0.0)}" else "PKR • • • • • •",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = (-0.5).sp
                            ),
                            color = PureWhite,
                            modifier = Modifier.testTag("user_balance_text")
                        )
                    }

                    // Raast ID / Level Pill
                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PureWhite.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = user?.kycTier?.replace("TIER_", "Tier ")?.replace("_", " ") ?: "Tier 1",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = PureWhite
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Raast: ${user?.mobileNumber ?: "0301-8472910"}",
                            fontSize = 11.sp,
                            color = MintLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Quick Action Buttons Row inside Balance Card
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickActionButton(
                        icon = Icons.Default.ArrowUpward,
                        label = LocalizedStrings.get("send_money", language),
                        onClick = onSendMoney,
                        testTag = "btn_send_money"
                    )
                    QuickActionButton(
                        icon = Icons.Default.ArrowDownward,
                        label = LocalizedStrings.get("receive_money", language),
                        onClick = onReceiveMoney,
                        testTag = "btn_receive_money"
                    )
                    QuickActionButton(
                        icon = Icons.Default.CallReceived,
                        label = LocalizedStrings.get("request_money", language),
                        onClick = onRequestMoney,
                        testTag = "btn_request_money"
                    )
                    QuickActionButton(
                        icon = Icons.Default.QrCodeScanner,
                        label = LocalizedStrings.get("qr_pay", language),
                        onClick = onScanQr,
                        testTag = "btn_scan_qr"
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(PureWhite.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = PureWhite,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = PureWhite,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TransactionRowItem(
    item: TransactionItem,
    onClick: () -> Unit
) {
    val isCredit = item.type == "RECEIVED_PAYMENT" || item.type == "CASH_IN"
    val icon = when (item.type) {
        "BANK_TRANSFER" -> Icons.Default.AccountBalance
        "WALLET_TRANSFER" -> Icons.Default.PhoneAndroid
        "BILL_PAYMENT" -> Icons.Default.ReceiptLong
        "MOBILE_TOPUP" -> Icons.Default.SimCard
        "REQUEST_PAID" -> Icons.Default.CallMade
        "RECEIVED_PAYMENT" -> Icons.Default.CallReceived
        "CASH_IN" -> Icons.Default.AddCard
        else -> Icons.Default.Payment
    }

    val iconBackground = when (item.type) {
        "BANK_TRANSFER" -> Color(0xFFEFF6FF)
        "WALLET_TRANSFER" -> Color(0xFFECFDF5)
        "BILL_PAYMENT" -> Color(0xFFFFFBEB)
        "MOBILE_TOPUP" -> Color(0xFFFAF5FF)
        else -> Color(0xFFF1F5F9)
    }

    val iconTint = when (item.type) {
        "BANK_TRANSFER" -> InfoBlue
        "WALLET_TRANSFER" -> EmeraldPrimary
        "BILL_PAYMENT" -> GoldAccent
        "MOBILE_TOPUP" -> Color(0xFF9333EA)
        else -> SlateTextPrimary
    }

    val timeFormatted = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(item.timestamp))

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = PureWhite,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("txn_item_${item.referenceNumber}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBackground),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = SlateTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${item.destinationInstitution} • $timeFormatted",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isCredit) "+ " else "- "}PKR ${"%,.2f".format(item.amount)}",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (isCredit) SuccessGreen else SlateTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (item.status == "SUCCESSFUL") MintLight else Color(0xFFFEE2E2)
                ) {
                    Text(
                        text = item.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (item.status == "SUCCESSFUL") EmeraldPrimary else ErrorRed,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
