package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditLogItem
import com.example.data.model.SupportTicketItem
import com.example.data.model.TransactionItem
import com.example.data.model.UserAccount
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminConsoleScreen(
    user: UserAccount?,
    transactions: List<TransactionItem>,
    supportTickets: List<SupportTicketItem>,
    auditLogs: List<AuditLogItem>,
    onBack: () -> Unit,
    onDepositSandbox: (Double) -> Unit,
    onUpgradeKyc: (String, String) -> Unit,
    onToggleLock: (Boolean) -> Unit,
    onResolveTicket: (Long, String) -> Unit
) {
    BackHandler { onBack() }

    var selectedSection by remember { mutableIntStateOf(0) } // 0: Overview, 1: KYC, 2: Rails, 3: Disputes, 4: Audit
    var responseInput by remember { mutableStateOf("") }
    var selectedTicketId by remember { mutableStateOf<Long?>(null) }

    val totalSettled = transactions.filter { it.status == "SUCCESSFUL" }.sumOf { it.amount }
    val totalCount = transactions.size

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "EASY PAY Admin Console",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                        Text(
                            text = "State Bank of Pakistan (SBP) Compliance & Operations",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldLight
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
        ) {
            // Admin Navigation Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedSection,
                containerColor = NavyDark,
                contentColor = GoldAccent,
                edgePadding = 12.dp
            ) {
                Tab(selected = selectedSection == 0, onClick = { selectedSection = 0 }, text = { Text("Overview & Liquidity") }, modifier = Modifier.testTag("admin_tab_overview"))
                Tab(selected = selectedSection == 1, onClick = { selectedSection = 1 }, text = { Text("KYC & Compliance") }, modifier = Modifier.testTag("admin_tab_kyc"))
                Tab(selected = selectedSection == 2, onClick = { selectedSection = 2 }, text = { Text("Payment Rails") }, modifier = Modifier.testTag("admin_tab_rails"))
                Tab(selected = selectedSection == 3, onClick = { selectedSection = 3 }, text = { Text("Disputes (${supportTickets.count { it.status == "OPEN" }})") }, modifier = Modifier.testTag("admin_tab_disputes"))
                Tab(selected = selectedSection == 4, onClick = { selectedSection = 4 }, text = { Text("Audit Trail") }, modifier = Modifier.testTag("admin_tab_audit"))
            }

            when (selectedSection) {
                0 -> {
                    // ================= OVERVIEW & LIQUIDITY =================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Key Metrics
                        item {
                            Text(
                                text = "Clearing & Settlement Metrics",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SlateTextPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                MetricCard(
                                    title = "Total Volume Cleared",
                                    value = "PKR ${"%,.0f".format(totalSettled)}",
                                    color = EmeraldPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                MetricCard(
                                    title = "Total Txn Count",
                                    value = totalCount.toString(),
                                    color = InfoBlue,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        // Sandbox Liquidity Injection Card
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                modifier = Modifier.fillMaxWidth().testTag("sandbox_liquidity_card")
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Savings, contentDescription = null, tint = EmeraldPrimary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Sandbox Balance & Liquidity Testing",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = SlateTextPrimary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Current user test balance: PKR ${"%,.2f".format(user?.balance ?: 0.0)}",
                                        fontSize = 13.sp,
                                        color = SlateTextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Button(
                                            onClick = { onDepositSandbox(25000.0) },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                            modifier = Modifier.weight(1f).testTag("admin_deposit_25k")
                                        ) {
                                            Text("+ 25,000 PKR", fontSize = 12.sp)
                                        }
                                        Button(
                                            onClick = { onDepositSandbox(50000.0) },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                            modifier = Modifier.weight(1f).testTag("admin_deposit_50k")
                                        ) {
                                            Text("+ 50,000 PKR", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // AML Lock / Restrict Account Toggle
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "AML Account Restriction Status",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = if (user?.isRestricted == true) "Account is restricted from making debit transfers." else "Account is active in good standing.",
                                            fontSize = 12.sp,
                                            color = if (user?.isRestricted == true) ErrorRed else SuccessGreen
                                        )
                                    }
                                    Switch(
                                        checked = user?.isRestricted == true,
                                        onCheckedChange = { onToggleLock(it) },
                                        modifier = Modifier.testTag("admin_toggle_aml_lock")
                                    )
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // ================= KYC & COMPLIANCE =================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "User Identity & Verification Profile",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = SlateTextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    KycDetailRow("Full Name", user?.fullName ?: "Muhammad Hamza")
                                    KycDetailRow("Pakistani CNIC", user?.cnic ?: "42101-9482716-3")
                                    KycDetailRow("Registered MSISDN", user?.mobileNumber ?: "0301-8472910")
                                    KycDetailRow("Current KYC Tier", user?.kycTier ?: "TIER_1_VERIFIED")
                                    KycDetailRow("Compliance Status", user?.kycStatus ?: "Verification Approved")
                                    KycDetailRow("Daily Spending Limit", "PKR ${"%,.2f".format(user?.dailyLimit ?: 50000.0)}")
                                    KycDetailRow("Monthly Spending Limit", "PKR ${"%,.2f".format(user?.monthlyLimit ?: 200000.0)}")

                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Update KYC Tier & Limits:",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = SlateTextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { onUpgradeKyc("TIER_1_VERIFIED", "Verification Approved") },
                                            colors = ButtonDefaults.buttonColors(containerColor = if (user?.kycTier == "TIER_1_VERIFIED") EmeraldPrimary else SlateBorder),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Tier 1 (50k)", fontSize = 11.sp, color = if (user?.kycTier == "TIER_1_VERIFIED") PureWhite else SlateTextPrimary)
                                        }
                                        Button(
                                            onClick = { onUpgradeKyc("TIER_2_ENHANCED", "Enhanced Verified") },
                                            colors = ButtonDefaults.buttonColors(containerColor = if (user?.kycTier == "TIER_2_ENHANCED") EmeraldPrimary else SlateBorder),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Tier 2 (200k)", fontSize = 11.sp, color = if (user?.kycTier == "TIER_2_ENHANCED") PureWhite else SlateTextPrimary)
                                        }
                                        Button(
                                            onClick = { onUpgradeKyc("TIER_3_MERCHANT", "Merchant Authorized") },
                                            colors = ButtonDefaults.buttonColors(containerColor = if (user?.kycTier == "TIER_3_MERCHANT") EmeraldPrimary else SlateBorder),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Tier 3 (1M)", fontSize = 11.sp, color = if (user?.kycTier == "TIER_3_MERCHANT") PureWhite else SlateTextPrimary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // ================= PAYMENT RAILS HEALTH =================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Inter-Bank & Clearing Switch Health",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SlateTextPrimary
                            )
                        }

                        val rails = listOf(
                            Triple("State Bank Raast ISO 20022", "OPERATIONAL • 99.98% Uptime", "180ms avg latency"),
                            Triple("1Link 1IBFT Inter-Bank Switch", "OPERATIONAL • 99.91% Uptime", "340ms avg latency"),
                            Triple("1Bill Utility Aggregator", "OPERATIONAL • 99.85% Uptime", "420ms avg latency"),
                            Triple("Telenor / Jazz Telco Direct APIs", "OPERATIONAL • 100% Uptime", "210ms avg latency"),
                            Triple("NADRA Biometric Verification Gateway", "CONNECTED • Standby", "610ms avg latency")
                        )

                        items(rails) { (name, status, ping) ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = SlateTextPrimary)
                                        Text(ping, fontSize = 11.sp, color = SlateTextSecondary)
                                    }
                                    Surface(shape = RoundedCornerShape(6.dp), color = MintLight) {
                                        Text(
                                            text = status,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldPrimary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // ================= DISPUTES & SUPPORT =================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Customer Support & Dispute Desk",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SlateTextPrimary
                            )
                        }

                        items(supportTickets) { ticket ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${ticket.ticketRef} • ${ticket.subject}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = SlateTextPrimary
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (ticket.status == "RESOLVED") MintLight else GoldLight
                                        ) {
                                            Text(
                                                text = ticket.status,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (ticket.status == "RESOLVED") EmeraldPrimary else GoldAccent,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Related Txn: ${ticket.relatedTxnRef}",
                                        fontSize = 11.sp,
                                        color = InfoBlue
                                    )
                                    Text(
                                        text = ticket.message,
                                        fontSize = 12.sp,
                                        color = SlateTextSecondary
                                    )

                                    if (ticket.adminResponse.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = SlateBackground,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "Admin Response: ${ticket.adminResponse}",
                                                fontSize = 11.sp,
                                                color = SlateTextPrimary,
                                                modifier = Modifier.padding(8.dp)
                                            )
                                        }
                                    }

                                    if (ticket.status != "RESOLVED") {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = {
                                                onResolveTicket(ticket.id, "Reviewed by compliance officer. Transaction confirmed settled with 1Link.")
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Mark Resolved", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // ================= AUDIT LOGS =================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text(
                                text = "Immutable Financial Audit Trail",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SlateTextPrimary
                            )
                        }

                        items(auditLogs) { log ->
                            val timeStr = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault()).format(Date(log.timestamp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PureWhite,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = log.action,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = EmeraldPrimary
                                        )
                                        Text(
                                            text = timeStr,
                                            fontSize = 10.sp,
                                            color = SlateTextSecondary
                                        )
                                    }
                                    Text(
                                        text = "Actor: ${log.actor}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NavyDark
                                    )
                                    Text(
                                        text = log.details,
                                        fontSize = 11.sp,
                                        color = SlateTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontSize = 11.sp, color = SlateTextSecondary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

@Composable
fun KycDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = SlateTextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SlateTextPrimary)
    }
}
