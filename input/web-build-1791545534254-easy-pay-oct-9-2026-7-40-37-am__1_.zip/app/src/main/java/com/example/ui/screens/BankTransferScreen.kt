package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccount
import com.example.data.repository.TransactionResult
import com.example.service.RailType
import com.example.service.RecipientInquiryResult
import com.example.service.TransferRequest
import com.example.ui.components.SecurityPinDialog
import com.example.ui.theme.*
import com.example.ui.util.BankInfo
import com.example.ui.util.PakistaniFintechCatalog
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BankTransferScreen(
    user: UserAccount?,
    onBack: () -> Unit,
    onInquireTitle: suspend (RailType, String, String) -> RecipientInquiryResult,
    onExecuteTransfer: (TransferRequest, String, (TransactionResult) -> Unit) -> Unit,
    onSaveBeneficiary: (String, String, String, String, String) -> Unit
) {
    BackHandler { onBack() }

    val coroutineScope = rememberCoroutineScope()
    var selectedBank by remember { mutableStateOf(PakistaniFintechCatalog.banks.first()) }
    var accountInput by remember { mutableStateOf("02010103829102") }
    var amountInput by remember { mutableStateOf("8500") }
    var purposeOfPayment by remember { mutableStateOf("Family Support") }
    var noteInput by remember { mutableStateOf("Monthly household transfer") }
    var saveAsBeneficiary by remember { mutableStateOf(true) }

    var inquiryResult by remember { mutableStateOf<RecipientInquiryResult?>(null) }
    var isInquiring by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showBankDropdown by remember { mutableStateOf(false) }

    val quickAmounts = listOf("1000", "5000", "8500", "15000", "25000")
    val purposes = listOf("Family Support", "Utility Bill", "Educational Fee", "Business / Vendor", "Loan Repayment")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Bank Transfer",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                        Text(
                            text = "1Link 1IBFT & Raast Instant Rail",
                            style = MaterialTheme.typography.labelSmall,
                            color = MintLight
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("bank_transfer_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = PureWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp)
                .testTag("bank_transfer_form"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Bank Selector Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Select Destination Bank",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SlateBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showBankDropdown = !showBankDropdown }
                                .testTag("select_bank_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalance,
                                        contentDescription = null,
                                        tint = EmeraldPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = selectedBank.name,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                        color = SlateTextPrimary
                                    )
                                }
                                Icon(
                                    imageVector = if (showBankDropdown) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = SlateTextSecondary
                                )
                            }
                        }

                        if (showBankDropdown) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                PakistaniFintechCatalog.banks.forEach { bank ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (bank.id == selectedBank.id) MintLight else PureWhite,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedBank = bank
                                                showBankDropdown = false
                                                inquiryResult = null
                                            }
                                    ) {
                                        Text(
                                            text = bank.name,
                                            fontSize = 13.sp,
                                            fontWeight = if (bank.id == selectedBank.id) FontWeight.Bold else FontWeight.Normal,
                                            color = if (bank.id == selectedBank.id) EmeraldPrimary else SlateTextPrimary,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Account Number / IBAN with Title Fetch
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Account Number or IBAN",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = accountInput,
                            onValueChange = {
                                accountInput = it
                                inquiryResult = null
                            },
                            placeholder = { Text("e.g. 02010103829102 or PK...IBAN") },
                            leadingIcon = {
                                Icon(Icons.Default.CreditCard, contentDescription = null, tint = EmeraldPrimary)
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("bank_account_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isInquiring = true
                                    errorMessage = null
                                    val result = onInquireTitle(
                                        RailType.ONE_LINK_IBFT,
                                        selectedBank.name,
                                        accountInput
                                    )
                                    isInquiring = false
                                    inquiryResult = result
                                }
                            },
                            enabled = accountInput.isNotBlank() && !isInquiring,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("fetch_title_btn")
                        ) {
                            if (isInquiring) {
                                CircularProgressIndicator(color = PureWhite, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Fetching Account Title...")
                            } else {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Fetch Account Title (1Link / Raast)")
                            }
                        }

                        // Title Inquiry Status Display
                        if (inquiryResult != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MintLight,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = EmeraldPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Verified Account Title:",
                                            fontSize = 11.sp,
                                            color = SlateTextSecondary
                                        )
                                        Text(
                                            text = inquiryResult?.recipientTitle ?: "",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = EmeraldDark
                                        )
                                        Text(
                                            text = inquiryResult?.message ?: "",
                                            fontSize = 11.sp,
                                            color = EmeraldPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 3. Amount Input & Quick Chips
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Transfer Amount (PKR)",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = { amountInput = it.filter { char -> char.isDigit() } },
                            leadingIcon = {
                                Text(
                                    text = "Rs.",
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldPrimary,
                                    modifier = Modifier.padding(start = 12.dp)
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("bank_amount_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Amount Chips
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(quickAmounts) { chipAmount ->
                                SuggestionChip(
                                    onClick = { amountInput = chipAmount },
                                    label = { Text("Rs. $chipAmount") }
                                )
                            }
                        }
                    }
                }
            }

            // 4. Purpose of Payment & Note
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Purpose of Payment (SBP Regulatory)",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(purposes) { p ->
                                FilterChip(
                                    selected = purposeOfPayment == p,
                                    onClick = { purposeOfPayment = p },
                                    label = { Text(p, fontSize = 12.sp) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            label = { Text("Note to Recipient (Optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = saveAsBeneficiary,
                                onCheckedChange = { saveAsBeneficiary = it }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Save recipient to My Beneficiaries",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateTextPrimary
                            )
                        }
                    }
                }
            }

            // Error display
            if (errorMessage != null) {
                item {
                    Text(
                        text = errorMessage ?: "",
                        color = ErrorRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // 5. Transfer Confirmation Action
            item {
                val amountDouble = amountInput.toDoubleOrNull() ?: 0.0
                Button(
                    onClick = {
                        if (amountDouble <= 0) {
                            errorMessage = "Please enter a valid amount."
                        } else if (inquiryResult == null) {
                            errorMessage = "Please fetch and verify account title before sending."
                        } else {
                            errorMessage = null
                            showPinDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_bank_transfer_btn")
                ) {
                    Text(
                        text = "Send PKR ${"%,.2f".format(amountDouble)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }

    // Security PIN dialog
    if (showPinDialog) {
        val amountDouble = amountInput.toDoubleOrNull() ?: 0.0
        val recipientTitle = inquiryResult?.recipientTitle ?: "Recipient"

        SecurityPinDialog(
            amount = amountDouble,
            recipient = "$recipientTitle (${selectedBank.code})",
            onPinConfirmed = { pin ->
                showPinDialog = false
                val req = TransferRequest(
                    amount = amountDouble,
                    recipientIdentifier = accountInput,
                    recipientTitle = recipientTitle,
                    institution = selectedBank.name,
                    purpose = purposeOfPayment,
                    note = noteInput,
                    railType = RailType.ONE_LINK_IBFT
                )
                onExecuteTransfer(req, pin) { result ->
                    if (result is TransactionResult.Success) {
                        if (saveAsBeneficiary) {
                            onSaveBeneficiary(recipientTitle, recipientTitle.take(15), accountInput, selectedBank.name, "BANK")
                        }
                        onBack()
                    } else if (result is TransactionResult.Error) {
                        errorMessage = result.reason
                    }
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }
}
