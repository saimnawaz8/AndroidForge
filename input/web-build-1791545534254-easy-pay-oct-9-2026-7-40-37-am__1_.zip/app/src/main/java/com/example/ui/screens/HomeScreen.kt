package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.MoneyRequestItem
import com.example.data.model.TransactionItem
import com.example.data.model.UserAccount
import com.example.ui.components.BalanceCard
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.*
import com.example.ui.util.AppLanguage
import com.example.ui.util.LocalizedStrings
import com.example.viewmodel.Screen

@Composable
fun HomeScreen(
    user: UserAccount?,
    transactions: List<TransactionItem>,
    moneyRequests: List<MoneyRequestItem>,
    isBalanceVisible: Boolean,
    language: AppLanguage,
    onToggleBalanceVisibility: () -> Unit,
    onNavigate: (Screen) -> Unit,
    onTransactionClick: (TransactionItem) -> Unit
) {
    val pendingRequests = moneyRequests.filter { it.status == "PENDING" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SlateBackground)
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Balance Card with Quick Transfer Actions
        item {
            BalanceCard(
                user = user,
                isBalanceVisible = isBalanceVisible,
                language = language,
                onToggleVisibility = onToggleBalanceVisibility,
                onSendMoney = { onNavigate(Screen.BankTransfer) },
                onReceiveMoney = { onNavigate(Screen.ReceiveMoney) },
                onRequestMoney = { onNavigate(Screen.RequestMoney) },
                onScanQr = { onNavigate(Screen.QrScanner) }
            )
        }

        // 2. Pending Money Requests Alert (if any)
        if (pendingRequests.isNotEmpty()) {
            item {
                val req = pendingRequests.first()
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GoldLight),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate(Screen.RequestMoney) }
                        .testTag("pending_request_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PendingActions,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Money Request Pending",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = NavyDark
                            )
                            Text(
                                text = "${req.requesterName} requested PKR ${"%,.2f".format(req.amount)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateTextPrimary
                            )
                        }
                        TextButton(onClick = { onNavigate(Screen.RequestMoney) }) {
                            Text("Review", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                        }
                    }
                }
            }
        }

        // 3. Financial Services Grid
        item {
            Text(
                text = "Services & Payments",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = SlateTextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ServiceTile(
                        icon = Icons.Default.AccountBalance,
                        title = LocalizedStrings.get("bank_transfer", language),
                        subtitle = "1Link & Raast Instant",
                        color = Color(0xFFEFF6FF),
                        iconTint = InfoBlue,
                        modifier = Modifier.weight(1f),
                        testTag = "service_bank_transfer",
                        onClick = { onNavigate(Screen.BankTransfer) }
                    )
                    ServiceTile(
                        icon = Icons.Default.PhoneAndroid,
                        title = LocalizedStrings.get("wallet_transfer", language),
                        subtitle = "Easypaisa, JazzCash",
                        color = Color(0xFFECFDF5),
                        iconTint = EmeraldPrimary,
                        modifier = Modifier.weight(1f),
                        testTag = "service_wallet_transfer",
                        onClick = { onNavigate(Screen.WalletTransfer) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ServiceTile(
                        icon = Icons.Default.ReceiptLong,
                        title = LocalizedStrings.get("bill_payments", language),
                        subtitle = "Electricity, Gas, Internet",
                        color = Color(0xFFFFFBEB),
                        iconTint = GoldAccent,
                        modifier = Modifier.weight(1f),
                        testTag = "service_bill_pay",
                        onClick = { onNavigate(Screen.PayAndBills) }
                    )
                    ServiceTile(
                        icon = Icons.Default.SimCard,
                        title = LocalizedStrings.get("mobile_topup", language),
                        subtitle = "Jazz, Zong, Ufone, Telenor",
                        color = Color(0xFFFAF5FF),
                        iconTint = Color(0xFF9333EA),
                        modifier = Modifier.weight(1f),
                        testTag = "service_mobile_topup",
                        onClick = { onNavigate(Screen.PayAndBills) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ServiceTile(
                        icon = Icons.Default.People,
                        title = LocalizedStrings.get("beneficiaries", language),
                        subtitle = "Quick Transfers",
                        color = Color(0xFFF1F5F9),
                        iconTint = SlateTextPrimary,
                        modifier = Modifier.weight(1f),
                        testTag = "service_beneficiaries",
                        onClick = { onNavigate(Screen.Beneficiaries) }
                    )
                    ServiceTile(
                        icon = Icons.Default.SupportAgent,
                        title = LocalizedStrings.get("support_desk", language),
                        subtitle = "Disputes & Inquiries",
                        color = Color(0xFFFEF2F2),
                        iconTint = ErrorRed,
                        modifier = Modifier.weight(1f),
                        testTag = "service_support",
                        onClick = { onNavigate(Screen.SupportCenter) }
                    )
                }
            }
        }

        // 4. Hero Promotional Banner (Generated Artwork)
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("promo_banner_card")
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Image(
                        painter = painterResource(id = R.drawable.banner_raast_promo_1791512242161),
                        contentDescription = "Pakistan's Digital Future",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        // 5. Recent Transactions Header & List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LocalizedStrings.get("recent_transactions", language),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = SlateTextPrimary
                )
                TextButton(
                    onClick = { onNavigate(Screen.Transactions) },
                    modifier = Modifier.testTag("view_all_transactions_btn")
                ) {
                    Text(
                        text = LocalizedStrings.get("view_all", language),
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                }
            }
        }

        if (transactions.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PureWhite,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = SlateTextSecondary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No recent transactions",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateTextSecondary
                        )
                    }
                }
            }
        } else {
            items(transactions.take(5)) { txn ->
                TransactionRowItem(item = txn, onClick = { onTransactionClick(txn) })
            }
        }
    }
}

@Composable
fun ServiceTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = PureWhite,
        tonalElevation = 1.dp,
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = SlateTextPrimary,
                    maxLines = 1
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateTextSecondary,
                    maxLines = 1
                )
            }
        }
    }
}
