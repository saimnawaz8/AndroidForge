package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccount
import com.example.data.repository.TransactionResult
import com.example.service.RailType
import com.example.service.RecipientInquiryResult
import com.example.service.TransferRequest
import com.example.ui.components.SecurityPinDialog
import com.example.ui.theme.*
import com.example.ui.util.BillerInfo
import com.example.ui.util.PakistaniFintechCatalog
import com.example.ui.util.TelecomPackage
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PayAndBillsScreen(
    user: UserAccount?,
    onBack: () -> Unit,
    onInquireTitle: suspend (RailType, String, String) -> RecipientInquiryResult,
    onExecuteTransfer: (TransferRequest, String, (TransactionResult) -> Unit) -> Unit
) {
    BackHandler { onBack() }

    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Bills, 1: Mobile

    // Bill payment states
    var selectedCategory by remember { mutableStateOf("Electricity") }
    var selectedBiller by remember { mutableStateOf(PakistaniFintechCatalog.billers.first()) }
    var consumerNumberInput by remember { mutableStateOf("08112739102837") }
    var billInquiryResult by remember { mutableStateOf<RecipientInquiryResult?>(null) }
    var billAmountInput by remember { mutableStateOf("4000") }
    var isBillInquiring by remember { mutableStateOf(false) }

    // Mobile top-up states
    var selectedOperator by remember { mutableStateOf("Jazz") }
    var targetMobileNumber by remember { mutableStateOf(user?.mobileNumber ?: "0301-8472910") }
    var customRechargeAmount by remember { mutableStateOf("500") }

    // Shared PIN dialog states
    var pendingRequest by remember { mutableStateOf<TransferRequest?>(null) }
    var showPinDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val categories = listOf("Electricity", "Gas", "Water", "Internet")
    val operators = listOf("Jazz", "Zong", "Ufone", "Telenor")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Pay & Recharge",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                        Text(
                            text = "1Bill Aggregator & Direct Telecom Rails",
                            style = MaterialTheme.typography.labelSmall,
                            color = MintLight
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("pay_bills_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = PureWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
        ) {
            // Tab Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = PureWhite,
                contentColor = EmeraldPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            "Utility & Govt Bills",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    modifier = Modifier.testTag("tab_utility_bills")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            "Mobile Packages & Load",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    modifier = Modifier.testTag("tab_mobile_packages")
                )
            }

            if (selectedTab == 0) {
                // ================= BILL PAYMENT TAB =================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Category Chips
                    item {
                        Text(
                            text = "Bill Category",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(categories) { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = {
                                        selectedCategory = cat
                                        selectedBiller = PakistaniFintechCatalog.billers.firstOrNull { it.category == cat }
                                            ?: PakistaniFintechCatalog.billers.first()
                                        consumerNumberInput = selectedBiller.sampleConsumer
                                        billInquiryResult = null
                                    },
                                    label = { Text(cat) },
                                    modifier = Modifier.testTag("bill_cat_$cat")
                                )
                            }
                        }
                    }

                    // Biller Selection Cards
                    item {
                        Text(
                            text = "Select Biller / Company",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val filteredBillers = PakistaniFintechCatalog.billers.filter { it.category == selectedCategory }
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            filteredBillers.forEach { biller ->
                                val isSelected = biller.id == selectedBiller.id
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) MintLight else PureWhite,
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) EmeraldPrimary else SlateBorder
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedBiller = biller
                                            consumerNumberInput = biller.sampleConsumer
                                            billInquiryResult = null
                                        }
                                        .testTag("biller_${biller.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Receipt,
                                            contentDescription = null,
                                            tint = if (isSelected) EmeraldPrimary else SlateTextSecondary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = biller.name,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                fontSize = 14.sp,
                                                color = SlateTextPrimary
                                            )
                                            Text(
                                                text = "${biller.consumerLength}-digit consumer number required",
                                                fontSize = 11.sp,
                                                color = SlateTextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Consumer Reference & Inquiry
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Consumer Reference Number",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SlateTextSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = consumerNumberInput,
                                    onValueChange = {
                                        consumerNumberInput = it
                                        billInquiryResult = null
                                    },
                                    placeholder = { Text("Enter reference number from paper bill") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("consumer_number_input")
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isBillInquiring = true
                                            errorMessage = null
                                            val result = onInquireTitle(
                                                RailType.ONE_BILL_UTILITY,
                                                selectedBiller.name,
                                                consumerNumberInput
                                            )
                                            isBillInquiring = false
                                            billInquiryResult = result
                                        }
                                    },
                                    enabled = consumerNumberInput.isNotBlank() && !isBillInquiring,
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("inquire_bill_btn")
                                ) {
                                    if (isBillInquiring) {
                                        CircularProgressIndicator(color = PureWhite, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Querying 1Bill Aggregator...")
                                    } else {
                                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Fetch Bill Details")
                                    }
                                }

                                if (billInquiryResult != null) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = GoldLight,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = "Consumer Title:",
                                                    fontSize = 11.sp,
                                                    color = SlateTextSecondary
                                                )
                                                Text(
                                                    text = "Status: UNPAID",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = ErrorRed
                                                )
                                            }
                                            Text(
                                                text = "${selectedBiller.id} - ${user?.fullName ?: "Consumer"}",
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = NavyDark
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Due Date: 15 Oct 2026 • Payable within Due Date",
                                                fontSize = 11.sp,
                                                color = SlateTextSecondary
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "Payable Amount:",
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = SlateTextPrimary
                                                )
                                                Text(
                                                    text = "PKR ${"%,.2f".format(billAmountInput.toDoubleOrNull() ?: 4000.0)}",
                                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                                    color = EmeraldPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (errorMessage != null) {
                        item {
                            Text(text = errorMessage ?: "", color = ErrorRed, fontSize = 13.sp)
                        }
                    }

                    // Pay Bill Action Button
                    item {
                        Button(
                            onClick = {
                                if (billInquiryResult == null) {
                                    errorMessage = "Please fetch bill details before proceeding."
                                } else {
                                    val amt = billAmountInput.toDoubleOrNull() ?: 4000.0
                                    pendingRequest = TransferRequest(
                                        amount = amt,
                                        recipientIdentifier = consumerNumberInput,
                                        recipientTitle = "${selectedBiller.name} Consumer",
                                        institution = selectedBiller.name,
                                        purpose = "Utility Bill Payment",
                                        note = "Consumer Ref: $consumerNumberInput",
                                        railType = RailType.ONE_BILL_UTILITY
                                    )
                                    showPinDialog = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("pay_bill_submit_btn")
                        ) {
                            Text("Pay Bill Now", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            } else {
                // ================= MOBILE TOP-UP & PACKAGES TAB =================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Mobile Number & Operator Filter
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Subscriber Mobile Number",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SlateTextSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = targetMobileNumber,
                                    onValueChange = { targetMobileNumber = it },
                                    placeholder = { Text("03XX-XXXXXXX") },
                                    leadingIcon = { Icon(Icons.Default.PhoneIphone, contentDescription = null, tint = EmeraldPrimary) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("mobile_recharge_input")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "Select Telecom Network",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SlateTextSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(operators) { op ->
                                        FilterChip(
                                            selected = selectedOperator == op,
                                            onClick = { selectedOperator = op },
                                            label = { Text(op) },
                                            modifier = Modifier.testTag("telco_op_$op")
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Direct Airtime Top-Up
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Easyload / Airtime Recharge (PKR)",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SlateTextPrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = customRechargeAmount,
                                        onValueChange = { customRechargeAmount = it.filter { c -> c.isDigit() } },
                                        label = { Text("Amount") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = {
                                            val amt = customRechargeAmount.toDoubleOrNull() ?: 100.0
                                            pendingRequest = TransferRequest(
                                                amount = amt,
                                                recipientIdentifier = targetMobileNumber,
                                                recipientTitle = "$selectedOperator Prepaid",
                                                institution = selectedOperator,
                                                purpose = "Mobile Airtime Topup",
                                                note = "Recharge to $targetMobileNumber",
                                                railType = RailType.TELCO_PREPAID
                                            )
                                            showPinDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.height(54.dp)
                                    ) {
                                        Text("Recharge")
                                    }
                                }
                            }
                        }
                    }

                    // Packages & Bundles Section
                    item {
                        Text(
                            text = "$selectedOperator Packages & Bundles",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = SlateTextPrimary
                        )
                    }

                    val filteredPackages = PakistaniFintechCatalog.packages.filter { it.operator.equals(selectedOperator, ignoreCase = true) }
                    items(filteredPackages) { pkg ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pkg_${pkg.id}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = pkg.name,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "Validity: ${pkg.validity}",
                                            fontSize = 11.sp,
                                            color = SlateTextSecondary
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MintLight
                                    ) {
                                        Text(
                                            text = "PKR ${pkg.price.toInt()}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = EmeraldPrimary,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Wifi, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(pkg.dataAllowance, fontSize = 12.sp, color = SlateTextPrimary)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Phone, contentDescription = null, tint = InfoBlue, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(pkg.callingMinutes, fontSize = 12.sp, color = SlateTextPrimary)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        pendingRequest = TransferRequest(
                                            amount = pkg.price,
                                            recipientIdentifier = targetMobileNumber,
                                            recipientTitle = "${pkg.operator} ${pkg.name}",
                                            institution = pkg.operator,
                                            purpose = "Telecom Bundle Subscription",
                                            note = "Subscribed to ${pkg.name}",
                                            railType = RailType.TELCO_PREPAID
                                        )
                                        showPinDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("subscribe_pkg_${pkg.id}")
                                ) {
                                    Text("Subscribe for PKR ${pkg.price.toInt()}")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Shared PIN Dialog
    if (showPinDialog && pendingRequest != null) {
        val req = pendingRequest!!
        SecurityPinDialog(
            amount = req.amount,
            recipient = "${req.recipientTitle} (${req.institution})",
            onPinConfirmed = { pin ->
                showPinDialog = false
                onExecuteTransfer(req, pin) { result ->
                    if (result is TransactionResult.Success) {
                        onBack()
                    } else if (result is TransactionResult.Error) {
                        errorMessage = result.reason
                    }
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }
}
