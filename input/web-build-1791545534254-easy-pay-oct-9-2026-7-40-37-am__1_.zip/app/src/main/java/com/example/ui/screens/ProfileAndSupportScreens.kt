package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotificationItem
import com.example.data.model.SupportTicketItem
import com.example.data.model.UserAccount
import com.example.ui.theme.*
import com.example.ui.util.AppLanguage
import com.example.ui.util.LocalizedStrings
import com.example.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    user: UserAccount?,
    language: AppLanguage,
    onBack: () -> Unit,
    onLanguageToggle: () -> Unit,
    onNavigate: (Screen) -> Unit
) {
    BackHandler { onBack() }
    var biometricsEnabled by remember { mutableStateOf(user?.biometricsEnabled ?: true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "My Profile & KYC",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("profile_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth().testTag("profile_user_card")
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MintLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "MH",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = user?.fullName ?: "Muhammad Hamza",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = SlateTextPrimary
                        )

                        Text(
                            text = "${user?.mobileNumber} • ${user?.email}",
                            fontSize = 12.sp,
                            color = SlateTextSecondary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(shape = RoundedCornerShape(12.dp), color = MintLight) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "NADRA Biometric Verified • Tier 1",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldDark
                                )
                            }
                        }
                    }
                }
            }

            // Spending Limits Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Account Spending Limits (PKR)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SlateTextPrimary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val dailyProgress = ((user?.dailySpent ?: 12500.0) / (user?.dailyLimit ?: 50000.0)).toFloat().coerceIn(0f, 1f)
                        Text(
                            text = "Daily Limit: PKR ${"%,.0f".format(user?.dailySpent ?: 0.0)} / PKR ${"%,.0f".format(user?.dailyLimit ?: 50000.0)}",
                            fontSize = 12.sp,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { dailyProgress },
                            color = EmeraldPrimary,
                            trackColor = SlateBorder,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        val monthlyProgress = ((user?.monthlySpent ?: 35000.0) / (user?.monthlyLimit ?: 200000.0)).toFloat().coerceIn(0f, 1f)
                        Text(
                            text = "Monthly Limit: PKR ${"%,.0f".format(user?.monthlySpent ?: 0.0)} / PKR ${"%,.0f".format(user?.monthlyLimit ?: 200000.0)}",
                            fontSize = 12.sp,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { monthlyProgress },
                            color = InfoBlue,
                            trackColor = SlateBorder,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )
                    }
                }
            }

            // Preferences & Settings
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Security & Preferences",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SlateTextPrimary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Biometric Authentication", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Use Fingerprint / Face ID for transfers", fontSize = 11.sp, color = SlateTextSecondary)
                            }
                            Switch(
                                checked = biometricsEnabled,
                                onCheckedChange = { biometricsEnabled = it }
                            )
                        }

                        HorizontalDivider(color = SlateBorder)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onLanguageToggle() }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("App Language", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("English / اردو (Urdu)", fontSize = 11.sp, color = SlateTextSecondary)
                            }
                            Text(
                                text = if (language == AppLanguage.ENGLISH) "English" else "اردو",
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                        }

                        HorizontalDivider(color = SlateBorder)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(Screen.SupportCenter) }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Customer Support & Complaints", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SlateTextSecondary)
                        }

                        HorizontalDivider(color = SlateBorder)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(Screen.AdminConsole) }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Compliance & Admin Portal", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = EmeraldPrimary)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = EmeraldPrimary)
                        }
                    }
                }
            }

            // Regulatory Disclaimer
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SlateBackground,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "EASY PAY is authorized under State Bank of Pakistan (SBP) Electronic Money Institutions (EMI) Regulations. Prototype build v1.0.4. All sandbox balances are for demonstration testing.",
                        fontSize = 11.sp,
                        color = SlateTextSecondary,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportCenterScreen(
    tickets: List<SupportTicketItem>,
    onBack: () -> Unit,
    onSubmitTicket: (String, String, String, String, () -> Unit) -> Unit
) {
    BackHandler { onBack() }

    var subjectInput by remember { mutableStateOf("") }
    var txnRefInput by remember { mutableStateOf("") }
    var messageInput by remember { mutableStateOf("") }
    var priorityInput by remember { mutableStateOf("NORMAL") }
    var isSubmittedSuccess by remember { mutableStateOf(false) }

    val faqs = listOf(
        Pair("How long do Raast transfers take?", "Raast transfers clear instantly 24/7 across all Pakistani banks with 0 fee."),
        Pair("What are the KYC limits?", "Tier 1: Rs. 50,000/day. Tier 2 (Enhanced biometric): Rs. 200,000/day."),
        Pair("How to report a duplicate bill charge?", "File a dispute below with the transaction reference number from your receipt.")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Help & Dispute Resolution",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("support_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // FAQs
            item {
                Text(
                    text = "Frequently Asked Questions",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = SlateTextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    faqs.forEach { (q, a) ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = q, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = a, fontSize = 12.sp, color = SlateTextSecondary)
                            }
                        }
                    }
                }
            }

            // File a Dispute Ticket
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth().testTag("ticket_form_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Report an Issue / Log a Ticket",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SlateTextPrimary
                        )

                        OutlinedTextField(
                            value = subjectInput,
                            onValueChange = { subjectInput = it },
                            label = { Text("Subject / Issue Type") },
                            placeholder = { Text("e.g. Delayed Bank Transfer or Bill Payment") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("ticket_subject_input")
                        )

                        OutlinedTextField(
                            value = txnRefInput,
                            onValueChange = { txnRefInput = it },
                            label = { Text("Transaction Reference (EP-...)") },
                            placeholder = { Text("e.g. EP-20261008-842109") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("ticket_ref_input")
                        )

                        OutlinedTextField(
                            value = messageInput,
                            onValueChange = { messageInput = it },
                            label = { Text("Detailed Explanation") },
                            modifier = Modifier.fillMaxWidth().height(100.dp).testTag("ticket_msg_input")
                        )

                        Button(
                            onClick = {
                                if (subjectInput.isNotBlank() && messageInput.isNotBlank()) {
                                    onSubmitTicket(subjectInput, txnRefInput, priorityInput, messageInput) {
                                        isSubmittedSuccess = true
                                        subjectInput = ""
                                        txnRefInput = ""
                                        messageInput = ""
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("submit_ticket_btn")
                        ) {
                            Text("Submit to Customer Desk")
                        }

                        if (isSubmittedSuccess) {
                            Surface(shape = RoundedCornerShape(8.dp), color = MintLight, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Your ticket was created. A compliance officer will review it shortly.",
                                    fontSize = 12.sp,
                                    color = EmeraldDark,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }
                }
            }

            // My Tickets List
            item {
                Text(
                    text = "My Support Tickets (${tickets.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = SlateTextPrimary
                )
            }

            items(tickets) { t ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${t.ticketRef} • ${t.subject}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (t.status == "RESOLVED") MintLight else GoldLight
                            ) {
                                Text(
                                    text = t.status,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (t.status == "RESOLVED") EmeraldPrimary else GoldAccent,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = t.message, fontSize = 12.sp, color = SlateTextSecondary)
                        if (t.adminResponse.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Desk Reply: ${t.adminResponse}",
                                fontSize = 11.sp,
                                color = EmeraldDark,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    notifications: List<NotificationItem>,
    onBack: () -> Unit,
    onMarkAllRead: () -> Unit
) {
    BackHandler { onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Notifications",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("notifications_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                actions = {
                    TextButton(onClick = onMarkAllRead) {
                        Text("Mark all read", color = MintLight, fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (notifications.isEmpty()) {
                item {
                    Text(
                        text = "No notifications",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateTextSecondary,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                items(notifications) { item ->
                    val timeStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(item.timestamp))
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        modifier = Modifier.fillMaxWidth().testTag("notif_item_${item.id}")
                    ) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (item.type == "TRANSFER") MintLight else Color(0xFFEFF6FF)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (item.type == "TRANSFER") Icons.Default.Payments else Icons.Default.Security,
                                    contentDescription = null,
                                    tint = if (item.type == "TRANSFER") EmeraldPrimary else InfoBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = SlateTextPrimary
                                    )
                                    Text(text = timeStr, fontSize = 10.sp, color = SlateTextSecondary)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = item.message,
                                    fontSize = 12.sp,
                                    color = SlateTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
