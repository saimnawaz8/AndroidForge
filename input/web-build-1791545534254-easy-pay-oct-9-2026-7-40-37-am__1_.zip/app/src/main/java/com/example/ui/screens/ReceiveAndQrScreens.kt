package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccount
import com.example.data.repository.TransactionResult
import com.example.service.RailType
import com.example.service.TransferRequest
import com.example.ui.components.SecurityPinDialog
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiveMoneyScreen(
    user: UserAccount?,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    var customAmountInput by remember { mutableStateOf("") }
    var isAmountCustomized by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Receive Money & QR",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("receive_money_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // QR Code Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.fillMaxWidth().testTag("receive_qr_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = user?.fullName ?: "EASY PAY User",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = SlateTextPrimary
                        )
                        Text(
                            text = "Raast Instant ID: ${user?.raastId ?: "03018472910@raast"}",
                            fontSize = 12.sp,
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Graphic QR Code Box
                        Box(
                            modifier = Modifier
                                .size(210.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .border(2.dp, SlateBorder, RoundedCornerShape(16.dp))
                                .background(PureWhite)
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            SimulatedQrCodeCanvas()
                            // Center Brand Emblem
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = PureWhite,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        if (isAmountCustomized && customAmountInput.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MintLight
                            ) {
                                Text(
                                    text = "Embedded Invoice: PKR ${customAmountInput}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldDark,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Scan with any Pakistani Bank or Wallet App (Raast / 1Link EMVCo)",
                            fontSize = 11.sp,
                            color = SlateTextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Set Specific Amount Toggle
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Request a Specific Amount",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = SlateTextPrimary
                            )
                            Switch(
                                checked = isAmountCustomized,
                                onCheckedChange = { isAmountCustomized = it }
                            )
                        }

                        if (isAmountCustomized) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = customAmountInput,
                                onValueChange = { customAmountInput = it.filter { c -> c.isDigit() } },
                                label = { Text("Amount (PKR)") },
                                leadingIcon = { Text("Rs.", fontWeight = FontWeight.Bold, color = EmeraldPrimary, modifier = Modifier.padding(start = 12.dp)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // Copyable Account Identifiers
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Receiving Details",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )

                        CopyRow(
                            label = "Raast Identifier",
                            value = user?.raastId ?: "03018472910@raast",
                            onCopy = { copyToClipboard(context, "Raast ID", user?.raastId ?: "") }
                        )

                        CopyRow(
                            label = "Mobile Number",
                            value = user?.mobileNumber ?: "0301-8472910",
                            onCopy = { copyToClipboard(context, "Mobile Number", user?.mobileNumber ?: "") }
                        )

                        CopyRow(
                            label = "EASY PAY IBAN",
                            value = user?.iban ?: "PK72EPAY0000103018472910",
                            onCopy = { copyToClipboard(context, "IBAN", user?.iban ?: "") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CopyRow(label: String, value: String, onCopy: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(SlateBackground)
            .clickable { onCopy() }
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = label, fontSize = 11.sp, color = SlateTextSecondary)
            Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SlateTextPrimary)
        }
        Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Copy",
            tint = EmeraldPrimary,
            modifier = Modifier.size(18.dp)
        )
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "$label copied to clipboard", Toast.LENGTH_SHORT).show()
}

@Composable
fun SimulatedQrCodeCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val step = w / 16f

        // Draw corner finder patterns
        drawRect(Color(0xFF0F172A), Offset(0f, 0f), Size(step * 5, step * 5))
        drawRect(Color.White, Offset(step, step), Size(step * 3, step * 3))
        drawRect(Color(0xFF0F172A), Offset(step * 1.5f, step * 1.5f), Size(step * 2, step * 2))

        drawRect(Color(0xFF0F172A), Offset(w - step * 5, 0f), Size(step * 5, step * 5))
        drawRect(Color.White, Offset(w - step * 4, step), Size(step * 3, step * 3))
        drawRect(Color(0xFF0F172A), Offset(w - step * 3.5f, step * 1.5f), Size(step * 2, step * 2))

        drawRect(Color(0xFF0F172A), Offset(0f, h - step * 5), Size(step * 5, step * 5))
        drawRect(Color.White, Offset(step, h - step * 4), Size(step * 3, step * 3))
        drawRect(Color(0xFF0F172A), Offset(step * 1.5f, h - step * 3.5f), Size(step * 2, step * 2))

        // Deterministic pseudo-QR pattern
        for (i in 0 until 16) {
            for (j in 0 until 16) {
                if ((i < 6 && j < 6) || (i > 10 && j < 6) || (i < 6 && j > 10)) continue
                if ((i * 7 + j * 13 + i * j) % 3 == 0) {
                    drawRect(
                        color = Color(0xFF0F172A),
                        topLeft = Offset(i * step, j * step),
                        size = Size(step * 0.9f, step * 0.9f)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrPayScreen(
    user: UserAccount?,
    onBack: () -> Unit,
    onExecuteTransfer: (TransferRequest, String, (TransactionResult) -> Unit) -> Unit
) {
    BackHandler { onBack() }

    val merchantPresets = listOf(
        Pair("Monal Restaurant (Margalla)", 3500.0),
        Pair("Al-Fatah Supermarket Lahore", 1850.0),
        Pair("PSO Fuel Station DHA", 4200.0),
        Pair("Chaye Khana F-6 Islamabad", 920.0)
    )

    var selectedMerchant by remember { mutableStateOf(merchantPresets.first()) }
    var showPinDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Scanner laser animation
    val infiniteTransition = rememberInfiniteTransition(label = "scanner")
    val laserPosition by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Scan & Pay QR",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("qr_pay_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Viewfinder Scanner Box
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .testTag("qr_scanner_viewfinder")
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        // Scanner box frame
                        Box(
                            modifier = Modifier
                                .size(180.dp)
                                .border(2.dp, MintAccent, RoundedCornerShape(16.dp))
                        ) {
                            // Animated Laser Line
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(3.dp)
                                    .offset(y = (laserPosition * 175).dp)
                                    .background(MintAccent)
                            )
                        }

                        Text(
                            text = "Align Merchant QR inside frame",
                            fontSize = 12.sp,
                            color = PureWhite.copy(alpha = 0.8f),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 12.dp)
                        )
                    }
                }
            }

            // Simulated Merchant Invoices Selection
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Select Detected Merchant QR Code",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SlateTextPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        merchantPresets.forEach { merchant ->
                            val isSelected = merchant.first == selectedMerchant.first
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MintLight else SlateBackground,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) EmeraldPrimary else SlateBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedMerchant = merchant }
                                    .padding(vertical = 4.dp)
                                    .testTag("qr_preset_${merchant.first.take(5)}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = merchant.first,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "EMVCo Merchant QR Validated",
                                            fontSize = 10.sp,
                                            color = EmeraldPrimary
                                        )
                                    }
                                    Text(
                                        text = "PKR ${"%,.2f".format(merchant.second)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isSelected) EmeraldPrimary else SlateTextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (errorMessage != null) {
                item {
                    Text(text = errorMessage ?: "", color = ErrorRed, fontSize = 13.sp)
                }
            }

            // Pay Merchant Button
            item {
                Button(
                    onClick = { showPinDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("pay_qr_submit_btn")
                ) {
                    Text(
                        text = "Pay PKR ${"%,.2f".format(selectedMerchant.second)} to Merchant",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }

    if (showPinDialog) {
        SecurityPinDialog(
            amount = selectedMerchant.second,
            recipient = selectedMerchant.first,
            onPinConfirmed = { pin ->
                showPinDialog = false
                val req = TransferRequest(
                    amount = selectedMerchant.second,
                    recipientIdentifier = "MERCHANT-${selectedMerchant.first.take(6).uppercase()}",
                    recipientTitle = selectedMerchant.first,
                    institution = "Raast Merchant Switch",
                    purpose = "QR Merchant Purchase",
                    note = "Invoice generated at ${selectedMerchant.first}",
                    railType = RailType.QR_MERCHANT
                )
                onExecuteTransfer(req, pin) { result ->
                    if (result is TransactionResult.Success) {
                        onBack()
                    } else if (result is TransactionResult.Error) {
                        errorMessage = result.reason
                    }
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }
}
