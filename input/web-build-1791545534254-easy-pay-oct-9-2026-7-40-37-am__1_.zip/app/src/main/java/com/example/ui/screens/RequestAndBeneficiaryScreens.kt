package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.BeneficiaryItem
import com.example.data.model.MoneyRequestItem
import com.example.data.repository.TransactionResult
import com.example.ui.components.SecurityPinDialog
import com.example.ui.theme.*
import com.example.ui.util.PakistaniFintechCatalog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequestMoneyScreen(
    moneyRequests: List<MoneyRequestItem>,
    onBack: () -> Unit,
    onCreateRequest: (String, Double, String, () -> Unit) -> Unit,
    onFulfillRequest: (MoneyRequestItem, String, (TransactionResult) -> Unit) -> Unit,
    onDeclineRequest: (Long) -> Unit
) {
    BackHandler { onBack() }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Create Request, 1: History
    var recipientPhone by remember { mutableStateOf("0333-1122334") }
    var requestAmount by remember { mutableStateOf("3500") }
    var requestNote by remember { mutableStateOf("Dinner split at Monal") }

    var payingRequest by remember { mutableStateOf<MoneyRequestItem?>(null) }
    var showPinDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Request Money",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("request_money_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = PureWhite,
                contentColor = EmeraldPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Send New Request", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Incoming Requests (${moneyRequests.count { it.status == "PENDING" }})", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            if (selectedTab == 0) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Recipient Mobile Number",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SlateTextSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = recipientPhone,
                                    onValueChange = { recipientPhone = it },
                                    placeholder = { Text("03XX-XXXXXXX") },
                                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EmeraldPrimary) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier.fillMaxWidth().testTag("req_phone_input")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "Requested Amount (PKR)",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SlateTextSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = requestAmount,
                                    onValueChange = { requestAmount = it.filter { c -> c.isDigit() } },
                                    leadingIcon = { Text("Rs.", fontWeight = FontWeight.Bold, color = EmeraldPrimary, modifier = Modifier.padding(start = 12.dp)) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("req_amount_input")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = requestNote,
                                    onValueChange = { requestNote = it },
                                    label = { Text("Reason / Note for Payer") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("req_note_input")
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        val amt = requestAmount.toDoubleOrNull() ?: 0.0
                                        if (amt > 0 && recipientPhone.isNotBlank()) {
                                            onCreateRequest(recipientPhone, amt, requestNote) {
                                                statusMessage = "Money request sent to $recipientPhone"
                                                selectedTab = 1
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("send_req_btn")
                                ) {
                                    Text("Send Payment Request", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (moneyRequests.isEmpty()) {
                        item {
                            Text(
                                text = "No money requests recorded",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateTextSecondary,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        items(moneyRequests) { req ->
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                modifier = Modifier.fillMaxWidth().testTag("req_item_${req.id}")
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = req.requesterName,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = SlateTextPrimary
                                            )
                                            Text(
                                                text = req.requesterPhone,
                                                fontSize = 11.sp,
                                                color = SlateTextSecondary
                                            )
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = when (req.status) {
                                                "PAID" -> MintLight
                                                "DECLINED" -> Color(0xFFFEE2E2)
                                                else -> GoldLight
                                            }
                                        ) {
                                            Text(
                                                text = req.status,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (req.status) {
                                                    "PAID" -> EmeraldPrimary
                                                    "DECLINED" -> ErrorRed
                                                    else -> GoldAccent
                                                },
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "Amount Requested:", color = SlateTextSecondary, fontSize = 13.sp)
                                        Text(
                                            text = "PKR ${"%,.2f".format(req.amount)}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = SlateTextPrimary
                                        )
                                    }

                                    if (req.note.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Note: ${req.note}",
                                            fontSize = 12.sp,
                                            color = SlateTextSecondary
                                        )
                                    }

                                    if (req.status == "PENDING") {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = { onDeclineRequest(req.id) },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Decline", color = ErrorRed)
                                            }
                                            Button(
                                                onClick = {
                                                    payingRequest = req
                                                    showPinDialog = true
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                                modifier = Modifier.weight(1f).testTag("pay_request_btn_${req.id}")
                                            ) {
                                                Text("Approve & Pay")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPinDialog && payingRequest != null) {
        val req = payingRequest!!
        SecurityPinDialog(
            amount = req.amount,
            recipient = req.requesterName,
            onPinConfirmed = { pin ->
                showPinDialog = false
                onFulfillRequest(req, pin) { result ->
                    if (result is TransactionResult.Success) {
                        onBack()
                    }
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BeneficiaryScreen(
    beneficiaries: List<BeneficiaryItem>,
    onBack: () -> Unit,
    onAddBeneficiary: (String, String, String, String, String) -> Unit,
    onDeleteBeneficiary: (BeneficiaryItem) -> Unit,
    onSelectForTransfer: (BeneficiaryItem) -> Unit
) {
    BackHandler { onBack() }

    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    val filtered = beneficiaries.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.institution.contains(searchQuery, ignoreCase = true) ||
                it.accountOrPhone.contains(searchQuery)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "My Beneficiaries",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("beneficiary_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = PureWhite,
                modifier = Modifier.testTag("add_beneficiary_fab")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add Beneficiary")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search beneficiary by name or account") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (filtered.isEmpty()) {
                item {
                    Text(
                        text = "No beneficiaries found. Tap + to add one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateTextSecondary,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                items(filtered) { item ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        modifier = Modifier.fillMaxWidth().testTag("beneficiary_card_${item.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(if (item.type == "BANK") Color(0xFFEFF6FF) else Color(0xFFECFDF5)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (item.type == "BANK") Icons.Default.AccountBalance else Icons.Default.PhoneAndroid,
                                        contentDescription = null,
                                        tint = if (item.type == "BANK") InfoBlue else EmeraldPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.name,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = SlateTextPrimary
                                        )
                                        if (item.isFavorite) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(Icons.Default.Star, contentDescription = "Favorite", tint = GoldAccent, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Text(
                                        text = "${item.institution} • ${item.accountOrPhone}",
                                        fontSize = 12.sp,
                                        color = SlateTextSecondary
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { onDeleteBeneficiary(item) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(20.dp))
                                }
                                Button(
                                    onClick = { onSelectForTransfer(item) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("send_to_beneficiary_${item.id}")
                                ) {
                                    Text("Send", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddBeneficiaryDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, nickname, acc, inst, type ->
                onAddBeneficiary(name, nickname, acc, inst, type)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddBeneficiaryDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var nickname by remember { mutableStateOf("") }
    var accountOrPhone by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("BANK") }
    var selectedInstitution by remember { mutableStateOf(PakistaniFintechCatalog.banks.first().name) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            modifier = Modifier.fillMaxWidth().padding(8.dp).testTag("add_beneficiary_dialog")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Add Beneficiary",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = SlateTextPrimary
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedType == "BANK",
                        onClick = {
                            selectedType = "BANK"
                            selectedInstitution = PakistaniFintechCatalog.banks.first().name
                        },
                        label = { Text("Bank") }
                    )
                    FilterChip(
                        selected = selectedType == "WALLET",
                        onClick = {
                            selectedType = "WALLET"
                            selectedInstitution = PakistaniFintechCatalog.wallets.first().name
                        },
                        label = { Text("Wallet") }
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Legal Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = nickname,
                    onValueChange = { nickname = it },
                    label = { Text("Nickname (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = accountOrPhone,
                    onValueChange = { accountOrPhone = it },
                    label = { Text(if (selectedType == "BANK") "Account Number / IBAN" else "Mobile Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank() && accountOrPhone.isNotBlank()) {
                                onSave(name, nickname, accountOrPhone, selectedInstitution, selectedType)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("Save Beneficiary")
                    }
                }
            }
        }
    }
}
