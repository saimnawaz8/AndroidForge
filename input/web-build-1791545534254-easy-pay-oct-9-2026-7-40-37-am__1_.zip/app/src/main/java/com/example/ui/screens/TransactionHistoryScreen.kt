package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionItem
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.*
import com.example.ui.util.AppLanguage
import com.example.ui.util.LocalizedStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionHistoryScreen(
    transactions: List<TransactionItem>,
    language: AppLanguage,
    onBack: () -> Unit,
    onTransactionClick: (TransactionItem) -> Unit
) {
    BackHandler { onBack() }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filterChips = listOf(
        Pair("ALL", "All"),
        Pair("BANK_TRANSFER", "Bank Transfers"),
        Pair("WALLET_TRANSFER", "Wallets"),
        Pair("BILL_PAYMENT", "Bills"),
        Pair("MOBILE_TOPUP", "Mobile"),
        Pair("RECEIVED_PAYMENT", "Received")
    )

    val filteredList = transactions.filter { txn ->
        val matchesSearch = txn.title.contains(searchQuery, ignoreCase = true) ||
                txn.recipientName.contains(searchQuery, ignoreCase = true) ||
                txn.destinationInstitution.contains(searchQuery, ignoreCase = true) ||
                txn.referenceNumber.contains(searchQuery, ignoreCase = true)

        val matchesFilter = if (selectedFilter == "ALL") true else txn.type == selectedFilter

        matchesSearch && matchesFilter
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = LocalizedStrings.get("transactions", language),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("history_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by reference, name, or bank...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("history_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filterChips) { (id, label) ->
                    FilterChip(
                        selected = selectedFilter == id,
                        onClick = { selectedFilter = id },
                        label = { Text(label, fontSize = 12.sp) },
                        modifier = Modifier.testTag("history_filter_$id")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Total summary line
            Text(
                text = "Showing ${filteredList.size} record${if (filteredList.size != 1) "s" else ""}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = SlateTextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // List of Transactions
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = SlateTextSecondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No matching transactions found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateTextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize().testTag("history_list")
                ) {
                    items(filteredList) { txn ->
                        TransactionRowItem(item = txn, onClick = { onTransactionClick(txn) })
                    }
                }
            }
        }
    }
}
