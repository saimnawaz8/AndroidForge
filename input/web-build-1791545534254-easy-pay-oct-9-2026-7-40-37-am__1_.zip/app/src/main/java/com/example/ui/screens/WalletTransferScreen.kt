package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccount
import com.example.data.repository.TransactionResult
import com.example.service.RailType
import com.example.service.RecipientInquiryResult
import com.example.service.TransferRequest
import com.example.ui.components.SecurityPinDialog
import com.example.ui.theme.*
import com.example.ui.util.PakistaniFintechCatalog
import com.example.ui.util.WalletInfo
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletTransferScreen(
    user: UserAccount?,
    onBack: () -> Unit,
    onInquireTitle: suspend (RailType, String, String) -> RecipientInquiryResult,
    onExecuteTransfer: (TransferRequest, String, (TransactionResult) -> Unit) -> Unit,
    onSaveBeneficiary: (String, String, String, String, String) -> Unit
) {
    BackHandler { onBack() }

    val coroutineScope = rememberCoroutineScope()
    var selectedWallet by remember { mutableStateOf(PakistaniFintechCatalog.wallets.first()) }
    var mobileInput by remember { mutableStateOf("0300-9876543") }
    var amountInput by remember { mutableStateOf("2500") }
    var noteInput by remember { mutableStateOf("Wallet P2P Transfer") }
    var saveBeneficiary by remember { mutableStateOf(true) }

    var inquiryResult by remember { mutableStateOf<RecipientInquiryResult?>(null) }
    var isInquiring by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val quickAmounts = listOf("500", "1000", "2500", "5000", "10000")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Send to Digital Wallet",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                        Text(
                            text = "Easypaisa, JazzCash, SadaPay & Raast",
                            style = MaterialTheme.typography.labelSmall,
                            color = MintLight
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("wallet_transfer_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = PureWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateBackground)
                .padding(innerPadding)
                .padding(16.dp)
                .testTag("wallet_transfer_form"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Wallet Provider Picker
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Select Digital Wallet Provider",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(PakistaniFintechCatalog.wallets) { wallet ->
                                val isSelected = wallet.id == selectedWallet.id
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (isSelected) Color(wallet.brandColorHex).copy(alpha = 0.12f) else SlateBackground,
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) Color(wallet.brandColorHex) else SlateBorder
                                    ),
                                    modifier = Modifier
                                        .clickable {
                                            selectedWallet = wallet
                                            inquiryResult = null
                                        }
                                        .testTag("wallet_pick_${wallet.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(Color(wallet.brandColorHex)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.PhoneIphone,
                                                contentDescription = null,
                                                tint = PureWhite,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = wallet.name,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = SlateTextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Recipient Mobile Number & Title Fetch
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Recipient Mobile Number",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = mobileInput,
                            onValueChange = {
                                mobileInput = it
                                inquiryResult = null
                            },
                            placeholder = { Text("03XX-XXXXXXX") },
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = EmeraldPrimary)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("wallet_mobile_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isInquiring = true
                                    errorMessage = null
                                    val rail = if (selectedWallet.id == "RAAST_P2P") RailType.RAAST_P2P else RailType.WALLET_DIRECT
                                    val result = onInquireTitle(rail, selectedWallet.name, mobileInput)
                                    isInquiring = false
                                    inquiryResult = result
                                }
                            },
                            enabled = mobileInput.isNotBlank() && !isInquiring,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("wallet_fetch_title_btn")
                        ) {
                            if (isInquiring) {
                                CircularProgressIndicator(color = PureWhite, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verifying Wallet Account...")
                            } else {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verify ${selectedWallet.name} Account")
                            }
                        }

                        // Verified Account Banner
                        if (inquiryResult != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MintLight,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = EmeraldPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Wallet Account Holder:",
                                            fontSize = 11.sp,
                                            color = SlateTextSecondary
                                        )
                                        Text(
                                            text = inquiryResult?.recipientTitle ?: "",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = EmeraldDark
                                        )
                                        Text(
                                            text = "Active account on ${selectedWallet.name}",
                                            fontSize = 11.sp,
                                            color = EmeraldPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 3. Amount & Chips
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Amount (PKR)",
                            style = MaterialTheme.typography.labelLarge,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = { amountInput = it.filter { char -> char.isDigit() } },
                            leadingIcon = {
                                Text(
                                    text = "Rs.",
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldPrimary,
                                    modifier = Modifier.padding(start = 12.dp)
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("wallet_amount_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(quickAmounts) { a ->
                                SuggestionChip(
                                    onClick = { amountInput = a },
                                    label = { Text("Rs. $a") }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            label = { Text("Payment Note (Optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = saveBeneficiary,
                                onCheckedChange = { saveBeneficiary = it }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Save to Favorite Beneficiaries",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateTextPrimary
                            )
                        }
                    }
                }
            }

            if (errorMessage != null) {
                item {
                    Text(
                        text = errorMessage ?: "",
                        color = ErrorRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Transfer action
            item {
                val amountDouble = amountInput.toDoubleOrNull() ?: 0.0
                Button(
                    onClick = {
                        if (amountDouble <= 0) {
                            errorMessage = "Please enter an amount."
                        } else if (inquiryResult == null) {
                            errorMessage = "Please verify wallet recipient title first."
                        } else {
                            errorMessage = null
                            showPinDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_wallet_transfer_btn")
                ) {
                    Text(
                        text = "Transfer PKR ${"%,.2f".format(amountDouble)} to ${selectedWallet.name}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }

    if (showPinDialog) {
        val amountDouble = amountInput.toDoubleOrNull() ?: 0.0
        val recipientTitle = inquiryResult?.recipientTitle ?: "Recipient"

        SecurityPinDialog(
            amount = amountDouble,
            recipient = "$recipientTitle (${selectedWallet.name})",
            onPinConfirmed = { pin ->
                showPinDialog = false
                val rail = if (selectedWallet.id == "RAAST_P2P") RailType.RAAST_P2P else RailType.WALLET_DIRECT
                val req = TransferRequest(
                    amount = amountDouble,
                    recipientIdentifier = mobileInput,
                    recipientTitle = recipientTitle,
                    institution = selectedWallet.name,
                    purpose = "Digital Wallet Transfer",
                    note = noteInput,
                    railType = rail
                )
                onExecuteTransfer(req, pin) { result ->
                    if (result is TransactionResult.Success) {
                        if (saveBeneficiary) {
                            onSaveBeneficiary(recipientTitle, recipientTitle.take(15), mobileInput, selectedWallet.name, "WALLET")
                        }
                        onBack()
                    } else if (result is TransactionResult.Error) {
                        errorMessage = result.reason
                    }
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }
}
