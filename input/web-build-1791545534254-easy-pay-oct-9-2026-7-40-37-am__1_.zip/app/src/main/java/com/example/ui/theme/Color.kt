package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// EASY PAY Pakistani Fintech Color Palette
val EmeraldPrimary = Color(0xFF064E3B) // Rich Emerald
val EmeraldDark = Color(0xFF022C22)    // Deep Forest
val EmeraldMedium = Color(0xFF0D5C3A)  // Card Gradient start
val MintAccent = Color(0xFF10B981)     // Vibrant Mint
val MintLight = Color(0xFFD1FAE5)      // Mint container
val NavyDark = Color(0xFF0A192F)       // Deep Navy
val NavySurface = Color(0xFF0F172A)    // Dark Mode Surface
val GoldAccent = Color(0xFFF59E0B)     // Rupee Gold
val GoldLight = Color(0xFFFEF3C7)      // Gold badge background

// Neutral & Status Colors
val PureWhite = Color(0xFFFFFFFF)
val SlateBackground = Color(0xFFF8FAFC)
val SlateCard = Color(0xFFFFFFFF)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF64748B)
val SlateBorder = Color(0xFFE2E8F0)
val ErrorRed = Color(0xFFDC2626)
val ErrorLight = Color(0xFFFEE2E2)
val SuccessGreen = Color(0xFF16A34A)
val InfoBlue = Color(0xFF2563EB)
val InfoLight = Color(0xFFDBEAFE)

// Dark Theme Colors
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF374151)
