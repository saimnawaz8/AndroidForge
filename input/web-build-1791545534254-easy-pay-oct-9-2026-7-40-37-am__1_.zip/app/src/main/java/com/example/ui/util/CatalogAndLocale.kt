package com.example.ui.util

enum class AppLanguage {
    ENGLISH,
    URDU
}

data class BankInfo(
    val id: String,
    val name: String,
    val code: String,
    val sampleIbanPrefix: String
)

data class WalletInfo(
    val id: String,
    val name: String,
    val brandColorHex: Long
)

data class BillerInfo(
    val id: String,
    val name: String,
    val category: String,
    val consumerLength: Int,
    val sampleConsumer: String
)

data class TelecomPackage(
    val id: String,
    val operator: String,
    val name: String,
    val validity: String,
    val dataAllowance: String,
    val callingMinutes: String,
    val price: Double
)

object PakistaniFintechCatalog {
    val banks = listOf(
        BankInfo("MEEZAN", "Meezan Bank Limited", "MEZN", "PK09MEZN"),
        BankInfo("HBL", "Habib Bank Limited (HBL)", "HABB", "PK89HABB"),
        BankInfo("UBL", "United Bank Limited (UBL)", "UNIL", "PK22UNIL"),
        BankInfo("MCB", "MCB Bank Limited", "MUCB", "PK45MUCB"),
        BankInfo("ALFALAH", "Bank Alfalah Limited", "ALFH", "PK12ALFH"),
        BankInfo("ALLIED", "Allied Bank Limited (ABL)", "ABPA", "PK33ABPA"),
        BankInfo("NBP", "National Bank of Pakistan", "NBPA", "PK10NBPA"),
        BankInfo("SCB", "Standard Chartered Pakistan", "SCBL", "PK77SCBL"),
        BankInfo("BOP", "The Bank of Punjab", "BPUN", "PK91BPUN"),
        BankInfo("FAYSAL", "Faysal Bank Limited", "FAYS", "PK62FAYS"),
        BankInfo("ASKARI", "Askari Bank Limited", "ASCM", "PK54ASCM")
    )

    val wallets = listOf(
        WalletInfo("EASYPAISA", "Easypaisa", 0xFF00A651),
        WalletInfo("JAZZCASH", "JazzCash", 0xFFED1C24),
        WalletInfo("SADAPAY", "SadaPay", 0xFF14B8A6),
        WalletInfo("NAYAPAY", "NayaPay", 0xFFF97316),
        WalletInfo("RAAST_P2P", "Raast P2P (Any Bank/Wallet)", 0xFF064E3B)
    )

    val billers = listOf(
        BillerInfo("LESCO", "LESCO (Electricity - Lahore)", "Electricity", 14, "08112739102837"),
        BillerInfo("KE", "K-Electric (Karachi)", "Electricity", 13, "0400018928172"),
        BillerInfo("IESCO", "IESCO (Islamabad Electric)", "Electricity", 14, "01123456789012"),
        BillerInfo("FESCO", "FESCO (Faisalabad Electric)", "Electricity", 14, "03145678901234"),
        BillerInfo("SNGPL", "SNGPL (Gas - Punjab & KP)", "Gas", 11, "82910294819"),
        BillerInfo("SSGC", "SSGC (Gas - Sindh & Balochistan)", "Gas", 10, "9182736450"),
        BillerInfo("WASA_LHR", "WASA Lahore (Water)", "Water", 10, "5544332211"),
        BillerInfo("PTCL", "PTCL Landline & Broadband", "Internet", 10, "0423588990"),
        BillerInfo("NAYATEL", "Nayatel Ultra Fiber", "Internet", 8, "76543210"),
        BillerInfo("STORMFIBER", "StormFiber Broadband", "Internet", 8, "99887766")
    )

    val packages = listOf(
        TelecomPackage("JAZZ_1", "Jazz", "Weekly Super Max", "7 Days", "30 GB", "6000 Jazz Mins, 150 Other", 450.0),
        TelecomPackage("JAZZ_2", "Jazz", "Monthly Mega", "30 Days", "12 GB Data", "No Calling", 699.0),
        TelecomPackage("JAZZ_3", "Jazz", "Super Card Grand", "30 Days", "35 GB Data", "5000 Jazz, 500 Other Mins", 1099.0),
        TelecomPackage("ZONG_1", "Zong", "Weekly Mega Data", "7 Days", "100 GB (1am-9am) + 15 GB", "100 All Net Mins", 480.0),
        TelecomPackage("ZONG_2", "Zong", "Monthly Super Star", "30 Days", "15 GB", "3000 Zong, 300 Other Mins", 750.0),
        TelecomPackage("UFONE_1", "Ufone", "Super Card Plus", "30 Days", "10 GB Data", "2000 Ufone, 350 Other Mins", 899.0),
        TelecomPackage("UFONE_2", "Ufone", "Weekly Digital", "7 Days", "15 GB Data", "1000 Ufone Mins", 390.0),
        TelecomPackage("TELENOR_1", "Telenor", "Easycard 1000", "30 Days", "18 GB Data", "2500 Telenor, 250 Other Mins", 950.0),
        TelecomPackage("TELENOR_2", "Telenor", "Weekly Ultra Plus", "7 Days", "20 GB Data", "Free Telenor Mins", 420.0)
    )
}

object LocalizedStrings {
    fun get(key: String, lang: AppLanguage): String {
        return when (lang) {
            AppLanguage.URDU -> urduStrings[key] ?: englishStrings[key] ?: key
            AppLanguage.ENGLISH -> englishStrings[key] ?: key
        }
    }

    private val englishStrings = mapOf(
        "app_tagline" to "Your Money. Your Control.",
        "sandbox_badge" to "SANDBOX PROTOTYPE",
        "available_balance" to "Available Balance",
        "hide_balance" to "Hide",
        "show_balance" to "Show",
        "send_money" to "Send Money",
        "receive_money" to "Receive",
        "request_money" to "Request",
        "bank_transfer" to "Bank Transfer",
        "wallet_transfer" to "Digital Wallets",
        "bill_payments" to "Bill Payments",
        "mobile_topup" to "Mobile Load & Bundles",
        "qr_pay" to "Scan & Pay",
        "beneficiaries" to "Beneficiaries",
        "recent_transactions" to "Recent Transactions",
        "view_all" to "View All",
        "all" to "All",
        "sent" to "Sent",
        "received" to "Received",
        "bills" to "Bills",
        "mobile" to "Mobile",
        "home" to "Home",
        "transactions" to "History",
        "pay_bills" to "Pay Bills",
        "admin" to "Admin",
        "profile" to "Profile",
        "raast_id" to "Raast ID",
        "account_limits" to "Daily / Monthly Limits",
        "tier_verified" to "Tier 1: CNIC Verified",
        "support_desk" to "24/7 Help & Disputes",
        "logout" to "Log Out"
    )

    private val urduStrings = mapOf(
        "app_tagline" to "آپ کا پیسہ، آپ کے ہاتھ میں",
        "sandbox_badge" to "سینڈ باکس پروٹوٹائپ",
        "available_balance" to "دستیاب رقم",
        "hide_balance" to "چھپائیں",
        "show_balance" to "دیکھیں",
        "send_money" to "رقم بھیجیں",
        "receive_money" to "رقم وصول کریں",
        "request_money" to "درخواست بھیجیں",
        "bank_transfer" to "بینک ٹرانسفر",
        "wallet_transfer" to "ڈیجیٹل والیٹس",
        "bill_payments" to "بلز کی ادائیگی",
        "mobile_topup" to "موبائل لوڈ و پیکجز",
        "qr_pay" to "کیو آر کوڈ سے ادائیگی",
        "beneficiaries" to "محفوظ افراد",
        "recent_transactions" to "حالیہ ٹرانزیکشنز",
        "view_all" to "تمام دیکھیں",
        "all" to "سب",
        "sent" to "بھیجی گئی",
        "received" to "موصول شدہ",
        "bills" to "بلز",
        "mobile" to "موبائل",
        "home" to "ہوم",
        "transactions" to "ریکارڈ",
        "pay_bills" to "ادائیگیاں",
        "admin" to "ایڈمن",
        "profile" to "پروفائل",
        "raast_id" to "راست آئی ڈی",
        "account_limits" to "روزانہ اور ماہانہ حد",
        "tier_verified" to "لیول ۱: شناختی کارڈ تصدیق شدہ",
        "support_desk" to "مدد اور شکایات",
        "logout" to "لاگ آؤٹ"
    )
}
