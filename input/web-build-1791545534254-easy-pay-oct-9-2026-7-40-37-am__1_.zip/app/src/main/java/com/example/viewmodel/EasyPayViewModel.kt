package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.EasyPayRepository
import com.example.data.repository.TransactionResult
import com.example.service.PaymentRouter
import com.example.service.RailType
import com.example.service.RecipientInquiryResult
import com.example.service.TransferRequest
import com.example.ui.util.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object Transactions : Screen()
    object PayAndBills : Screen()
    object AdminConsole : Screen()
    object Profile : Screen()
    object BankTransfer : Screen()
    object WalletTransfer : Screen()
    object RequestMoney : Screen()
    object ReceiveMoney : Screen()
    object QrScanner : Screen()
    object Beneficiaries : Screen()
    object Notifications : Screen()
    object SupportCenter : Screen()
    object KycUpgrade : Screen()
}

class EasyPayViewModel(private val repository: EasyPayRepository) : ViewModel() {

    val userAccount: StateFlow<UserAccount?> = repository.userAccount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val transactions: StateFlow<List<TransactionItem>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val beneficiaries: StateFlow<List<BeneficiaryItem>> = repository.beneficiaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val moneyRequests: StateFlow<List<MoneyRequestItem>> = repository.moneyRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val supportTickets: StateFlow<List<SupportTicketItem>> = repository.supportTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogItem>> = repository.auditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _isBalanceVisible = MutableStateFlow(true)
    val isBalanceVisible: StateFlow<Boolean> = _isBalanceVisible.asStateFlow()

    private val _activeScreen = MutableStateFlow<Screen>(Screen.Home)
    val activeScreen: StateFlow<Screen> = _activeScreen.asStateFlow()

    private val _screenBackStack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))

    private val _selectedTransaction = MutableStateFlow<TransactionItem?>(null)
    val selectedTransaction: StateFlow<TransactionItem?> = _selectedTransaction.asStateFlow()

    private val _operationStatus = MutableStateFlow<String?>(null)
    val operationStatus: StateFlow<String?> = _operationStatus.asStateFlow()

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.ENGLISH) {
            AppLanguage.URDU
        } else {
            AppLanguage.ENGLISH
        }
    }

    fun toggleBalanceVisibility() {
        _isBalanceVisible.value = !_isBalanceVisible.value
    }

    fun navigateTo(screen: Screen) {
        _activeScreen.value = screen
        _screenBackStack.value = _screenBackStack.value + screen
    }

    fun navigateBack(): Boolean {
        val currentStack = _screenBackStack.value
        if (currentStack.size > 1) {
            val newStack = currentStack.dropLast(1)
            _screenBackStack.value = newStack
            _activeScreen.value = newStack.last()
            return true
        } else if (_activeScreen.value != Screen.Home) {
            _activeScreen.value = Screen.Home
            _screenBackStack.value = listOf(Screen.Home)
            return true
        }
        return false
    }

    fun showReceipt(transaction: TransactionItem) {
        _selectedTransaction.value = transaction
    }

    fun dismissReceipt() {
        _selectedTransaction.value = null
    }

    fun clearStatus() {
        _operationStatus.value = null
    }

    suspend fun inquireTitle(railType: RailType, institution: String, identifier: String): RecipientInquiryResult {
        val adapter = PaymentRouter.getAdapterFor(railType)
        return adapter.inquireTitle(institution, identifier)
    }

    fun executeTransfer(
        request: TransferRequest,
        enteredPin: String,
        onComplete: (TransactionResult) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.executePayment(request, enteredPin)
            if (result is TransactionResult.Success) {
                _selectedTransaction.value = result.transaction
            }
            onComplete(result)
        }
    }

    fun sendMoneyRequest(targetPhone: String, amount: Double, note: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.createMoneyRequest(targetPhone, amount, note)
            onDone()
        }
    }

    fun fulfillRequest(request: MoneyRequestItem, pin: String, onComplete: (TransactionResult) -> Unit) {
        viewModelScope.launch {
            val result = repository.fulfillMoneyRequest(request.id, request, pin)
            onComplete(result)
        }
    }

    fun declineRequest(requestId: Long) {
        viewModelScope.launch {
            repository.declineMoneyRequest(requestId)
        }
    }

    fun addBeneficiary(name: String, nickname: String, accountOrPhone: String, institution: String, type: String) {
        viewModelScope.launch {
            repository.addBeneficiary(name, nickname, accountOrPhone, institution, type)
            _operationStatus.value = "Beneficiary '$name' saved successfully"
        }
    }

    fun deleteBeneficiary(item: BeneficiaryItem) {
        viewModelScope.launch {
            repository.deleteBeneficiary(item)
            _operationStatus.value = "Beneficiary removed"
        }
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun fileSupportTicket(subject: String, relatedTxnRef: String, priority: String, message: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.fileSupportTicket(subject, relatedTxnRef, priority, message)
            _operationStatus.value = "Support ticket registered. Our 24/7 team is reviewing."
            onDone()
        }
    }

    // Admin & Compliance methods
    fun adminDepositSandboxFunds(amount: Double) {
        viewModelScope.launch {
            repository.sandboxDeposit(amount)
            _operationStatus.value = "Sandbox balance credited with PKR ${"%,.2f".format(amount)}"
        }
    }

    fun adminUpgradeKyc(tier: String, status: String) {
        viewModelScope.launch {
            repository.updateKycTier(tier, status)
            _operationStatus.value = "User KYC updated to $tier ($status)"
        }
    }

    fun adminToggleLock(isRestricted: Boolean) {
        viewModelScope.launch {
            repository.toggleUserRestriction(isRestricted)
            _operationStatus.value = if (isRestricted) "Account restricted by compliance" else "Account unlocked"
        }
    }

    fun adminResolveTicket(ticketId: Long, response: String) {
        viewModelScope.launch {
            repository.resolveSupportTicket(ticketId, response)
            _operationStatus.value = "Ticket marked RESOLVED with response"
        }
    }
}
