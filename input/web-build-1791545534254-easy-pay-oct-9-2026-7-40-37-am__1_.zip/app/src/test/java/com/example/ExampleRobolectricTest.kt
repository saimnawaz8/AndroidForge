package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.service.PaymentRouter
import com.example.service.RailType
import com.example.ui.util.PakistaniFintechCatalog
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun testAppNameIsEasyPay() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("EASY PAY", appName)
  }

  @Test
  fun testPakistaniBanksCatalog() {
    val banks = PakistaniFintechCatalog.banks
    assertTrue("Pakistani bank catalog must contain top banks", banks.isNotEmpty())
    val meezan = banks.find { it.id == "MEEZAN" }
    assertNotNull(meezan)
    assertEquals("MEZN", meezan?.code)
  }

  @Test
  fun testRaastTitleInquiry() = runBlocking {
    val adapter = PaymentRouter.raastAdapter
    assertEquals(RailType.RAAST_P2P, adapter.railType)
    val result = adapter.inquireTitle("Meezan Bank", "0301-8472910")
    assertTrue(result.isValid)
    assertEquals(0.0, result.fee, 0.001)
  }
}
